from __future__ import absolute_import

# flake8: noqa

# import apis into api package
from WeisWSClient.api.acquisition_sessions_api import AcquisitionSessionsApi
from WeisWSClient.api.actuators_api import ActuatorsApi
from WeisWSClient.api.annotations_api import AnnotationsApi
from WeisWSClient.api.api_api import ApiApi
from WeisWSClient.api.brapiv1calls_api import Brapiv1callsApi
from WeisWSClient.api.brapiv1studies_api import Brapiv1studiesApi
from WeisWSClient.api.brapiv1studies_search_api import Brapiv1studiesSearchApi
from WeisWSClient.api.brapiv1token_api import Brapiv1tokenApi
from WeisWSClient.api.brapiv1traits_api import Brapiv1traitsApi
from WeisWSClient.api.brapiv1variables_api import Brapiv1variablesApi
from WeisWSClient.api.data_api import DataApi
from WeisWSClient.api.datasets_api import DatasetsApi
from WeisWSClient.api.documents_api import DocumentsApi
from WeisWSClient.api.environments_api import EnvironmentsApi
from WeisWSClient.api.events_api import EventsApi
from WeisWSClient.api.experiments_api import ExperimentsApi
from WeisWSClient.api.group_api import GroupApi
from WeisWSClient.api.images_api import ImagesApi
from WeisWSClient.api.infrastructures_api import InfrastructuresApi
from WeisWSClient.api.layers_api import LayersApi
from WeisWSClient.api.methods_api import MethodsApi
from WeisWSClient.api.projects_api import ProjectsApi
from WeisWSClient.api.provenances_api import ProvenancesApi
from WeisWSClient.api.radiometric_targets_api import RadiometricTargetsApi
from WeisWSClient.api.scientific_objects_api import ScientificObjectsApi
from WeisWSClient.api.sensors_api import SensorsApi
from WeisWSClient.api.species_api import SpeciesApi
from WeisWSClient.api.traits_api import TraitsApi
from WeisWSClient.api.triplets_api import TripletsApi
from WeisWSClient.api.units_api import UnitsApi
from WeisWSClient.api.uri_api import UriApi
from WeisWSClient.api.user_api import UserApi
from WeisWSClient.api.variables_api import VariablesApi
from WeisWSClient.api.vectors_api import VectorsApi
from WeisWSClient.api.vocabularies_api import VocabulariesApi
