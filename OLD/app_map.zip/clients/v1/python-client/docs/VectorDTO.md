# VectorDTO

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**uri** | **str** |  | [optional] 
**rdf_type** | **str** |  | [optional] 
**label** | **str** |  | [optional] 
**brand** | **str** |  | [optional] 
**serial_number** | **str** |  | [optional] 
**in_service_date** | **str** |  | [optional] 
**date_of_purchase** | **str** |  | [optional] 
**person_in_charge** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


