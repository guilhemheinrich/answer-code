# ExperimentPostDTO

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**start_date** | **str** |  | [optional] 
**end_date** | **str** |  | [optional] 
**field** | **str** |  | [optional] 
**campaign** | **str** |  | [optional] 
**place** | **str** |  | [optional] 
**alias** | **str** |  | [optional] 
**comment** | **str** |  | [optional] 
**keywords** | **str** |  | [optional] 
**objective** | **str** |  | [optional] 
**crop_species** | **str** |  | [optional] 
**projects_uris** | **list[str]** |  | [optional] 
**groups_uris** | **list[str]** |  | [optional] 
**contacts** | [**list[ContactPostgreSQL]**](ContactPostgreSQL.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


