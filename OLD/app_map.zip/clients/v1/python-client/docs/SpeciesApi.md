# WeisWSClient.SpeciesApi

All URIs are relative to *http://www.opensilex.org:8080/weisAPI/rest*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get**](SpeciesApi.md#get) | **GET** /species | Get all species corresponding to the search params given


# **get**
> list[SpeciesDTO] get(authorization, page_size=page_size, page=page, uri=uri, label=label, language=language)

Get all species corresponding to the search params given

Retrieve all species authorized for the user corresponding to the searched params given

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.SpeciesApi(pythonClient)
page_size = 20 # int | Number of elements per page (limited to 150000) (optional) (default to 20)
page = 0 # int | Current page number (optional) (default to 0)
uri = '\"http://www.opensilex.org/id/species/maize\"' # str | Search by species uri (optional)
label = '\"Maize\"' # str | Search by species label (optional)
language = '\"en\"' # str | Select language (optional)


try:
    # Get all species corresponding to the search params given
    api_response = api_instance.get(page_size=page_size, page=page, uri=uri, label=label, language=language)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SpeciesApi->get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page_size** | **int**| Number of elements per page (limited to 150000) | [optional] [default to 20]
 **page** | **int**| Current page number | [optional] [default to 0]
 **uri** | **str**| Search by species uri | [optional] 
 **label** | **str**| Search by species label | [optional] 
 **language** | **str**| Select language | [optional] 


### Return type

[**list[SpeciesDTO]**](SpeciesDTO.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

