# StudyDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**study_db_id** | **str** |  | [optional] 
**study_name** | **str** |  | [optional] 
**study_type_db_id** | **str** |  | [optional] 
**study_type_name** | **str** |  | [optional] 
**study_description** | **str** |  | [optional] 
**seasons** | **list[str]** |  | [optional] 
**common_crop_name** | **str** |  | [optional] 
**trial_db_id** | **str** |  | [optional] 
**trial_name** | **str** |  | [optional] 
**start_date** | **str** |  | [optional] 
**end_date** | **str** |  | [optional] 
**active** | **bool** |  | [optional] 
**license** | **str** |  | [optional] 
**location** | **str** |  | [optional] 
**contacts** | [**list[ContactBrapi]**](ContactBrapi.md) |  | [optional] 
**data_links** | **list[str]** |  | [optional] 
**last_update** | **list[str]** |  | [optional] 
**additional_info** | **dict(str, str)** |  | [optional] 
**documentation_url** | **str** |  | [optional] 
**study_type** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


