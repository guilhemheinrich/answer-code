# WeisWSClient.VectorsApi

All URIs are relative to *http://www.opensilex.org:8080/weisAPI/rest*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_vector_details**](VectorsApi.md#get_vector_details) | **GET** /vectors/{uri} | Get a vector
[**get_vectors_by_search**](VectorsApi.md#get_vectors_by_search) | **GET** /vectors | Get all vectors corresponding to the search params given
[**post6**](VectorsApi.md#post6) | **POST** /vectors | Post a vector
[**put7**](VectorsApi.md#put7) | **PUT** /vectors | Update vector


# **get_vector_details**
> list[Vector] get_vector_details(uri, authorization, page_size=page_size, page=page)

Get a vector

Retrieve a vector. Need URL encoded vector URI

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.VectorsApi(pythonClient)
uri = '\"http://www.opensilex.org/demo/2018/v1801\"' # str | a sensor URI (Unique Resource Identifier)
page_size = 20 # int | Number of elements per page (limited to 150000) (optional) (default to 20)
page = 0 # int | Current page number (optional) (default to 0)


try:
    # Get a vector
    api_response = api_instance.get_vector_details(uri, page_size=page_size, page=page)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling VectorsApi->get_vector_details: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **uri** | **str**| a sensor URI (Unique Resource Identifier) | 
 **page_size** | **int**| Number of elements per page (limited to 150000) | [optional] [default to 20]
 **page** | **int**| Current page number | [optional] [default to 0]


### Return type

[**list[Vector]**](Vector.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_vectors_by_search**
> list[Vector] get_vectors_by_search(authorization, page_size=page_size, page=page, uri=uri, rdf_type=rdf_type, label=label, brand=brand, serial_number=serial_number, in_service_date=in_service_date, date_of_purchase=date_of_purchase, person_in_charge=person_in_charge)

Get all vectors corresponding to the search params given

Retrieve all vectors authorized for the user corresponding to the searched params given

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.VectorsApi(pythonClient)
page_size = 20 # int | Number of elements per page (limited to 150000) (optional) (default to 20)
page = 0 # int | Current page number (optional) (default to 0)
uri = '\"http://www.opensilex.org/demo/2018/v1801\"' # str | Search by uri (optional)
rdf_type = '\"http://www.opensilex.org/vocabulary/oeso#UAV\"' # str | Search by rdf type (optional)
label = '\"par03_p\"' # str | Search by label (optional)
brand = '\"Skye Instruments\"' # str | Search by brand (optional)
serial_number = '\"A1E345F32\"' # str | Search by serial number (optional)
in_service_date = '\"2017-06-15\"' # str | Search by service date (optional)
date_of_purchase = '\"2017-06-15\"' # str | Search by date of purchase (optional)
person_in_charge = '\"admin@opensilex.org\"' # str | Search by person in charge (optional)


try:
    # Get all vectors corresponding to the search params given
    api_response = api_instance.get_vectors_by_search(page_size=page_size, page=page, uri=uri, rdf_type=rdf_type, label=label, brand=brand, serial_number=serial_number, in_service_date=in_service_date, date_of_purchase=date_of_purchase, person_in_charge=person_in_charge)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling VectorsApi->get_vectors_by_search: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page_size** | **int**| Number of elements per page (limited to 150000) | [optional] [default to 20]
 **page** | **int**| Current page number | [optional] [default to 0]
 **uri** | **str**| Search by uri | [optional] 
 **rdf_type** | **str**| Search by rdf type | [optional] 
 **label** | **str**| Search by label | [optional] 
 **brand** | **str**| Search by brand | [optional] 
 **serial_number** | **str**| Search by serial number | [optional] 
 **in_service_date** | **str**| Search by service date | [optional] 
 **date_of_purchase** | **str**| Search by date of purchase | [optional] 
 **person_in_charge** | **str**| Search by person in charge | [optional] 


### Return type

[**list[Vector]**](Vector.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post6**
> ResponseFormPOST post6(authorization, body=body)

Post a vector

Register a new vector in the database

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.VectorsApi(pythonClient)
body = [WeisWSClient.VectorDTO()] # list[VectorDTO] | JSON format of vector data (optional)


try:
    # Post a vector
    api_response = api_instance.post6(body=body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling VectorsApi->post6: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**list[VectorDTO]**](VectorDTO.md)| JSON format of vector data | [optional] 


### Return type

[**ResponseFormPOST**](ResponseFormPOST.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **put7**
> ResponseFormPOST put7(authorization, body=body)

Update vector



### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.VectorsApi(pythonClient)
body = [WeisWSClient.VectorDTO()] # list[VectorDTO] | JSON format of vector data (optional)


try:
    # Update vector
    api_response = api_instance.put7(body=body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling VectorsApi->put7: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**list[VectorDTO]**](VectorDTO.md)| JSON format of vector data | [optional] 


### Return type

[**ResponseFormPOST**](ResponseFormPOST.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

