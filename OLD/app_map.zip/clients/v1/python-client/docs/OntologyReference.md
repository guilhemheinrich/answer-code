# OntologyReference

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_property** | **str** |  | [optional] 
**object** | **str** |  | [optional] 
**see_also** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


