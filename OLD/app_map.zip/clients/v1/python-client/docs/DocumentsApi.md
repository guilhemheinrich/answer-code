# WeisWSClient.DocumentsApi

All URIs are relative to *http://www.opensilex.org:8080/weisAPI/rest*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_document_by_uri**](DocumentsApi.md#get_document_by_uri) | **GET** /documents/{documentURI} | Get a document (by receiving it&#39;s uri)
[**get_documents_metadata_by_search**](DocumentsApi.md#get_documents_metadata_by_search) | **GET** /documents | Get all documents metadata corresponding to the searched params given
[**get_documents_type**](DocumentsApi.md#get_documents_type) | **GET** /documents/types | Get all documents types
[**post_document_file**](DocumentsApi.md#post_document_file) | **POST** /documents/upload | Post data file
[**post_documents**](DocumentsApi.md#post_documents) | **POST** /documents | Save a file
[**put_document_metadata**](DocumentsApi.md#put_document_metadata) | **PUT** /documents | Update document metadata


# **get_document_by_uri**
> get_document_by_uri(document_uri, authorization)

Get a document (by receiving it's uri)

Retrieve the document corresponding to the uri given

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.DocumentsApi(pythonClient)
document_uri = '\"http://www.opensilex.org/demo/documents/documente597f57ba71d421a86277d830f4b9885\"' # str | A document URI (Unique Resource Identifier)


try:
    # Get a document (by receiving it's uri)
    api_instance.get_document_by_uri(document_uri, )
except ApiException as e:
    print("Exception when calling DocumentsApi->get_document_by_uri: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **document_uri** | **str**| A document URI (Unique Resource Identifier) | 


### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/octet-stream

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_documents_metadata_by_search**
> list[DocumentMetadataDTO] get_documents_metadata_by_search(authorization, page_size=page_size, page=page, uri=uri, document_type=document_type, creator=creator, language=language, title=title, creation_date=creation_date, extension=extension, concerned_item=concerned_item, status=status, sort_by_date=sort_by_date)

Get all documents metadata corresponding to the searched params given

Retrieve all documents authorized for the user corresponding to the searched params given

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.DocumentsApi(pythonClient)
page_size = 20 # int | Number of elements per page (limited to 150000) (optional) (default to 20)
page = 0 # int | Current page number (optional) (default to 0)
uri = '\"http://www.opensilex.org/demo/documents/documente597f57ba71d421a86277d830f4b9885\"' # str | Search by URI (optional)
document_type = '\"http://www.opensilex.org/vocabulary/oeso#ScientificDocument\"' # str | Search by document type (optional)
creator = '\"John Doe\"' # str | Search by creator (optional)
language = '\"fr\"' # str | Search by language (optional)
title = '\"title\"' # str | Search by title (optional)
creation_date = '\"2017-07-07\"' # str | Search by creation date (optional)
extension = '\"png\"' # str | Search by extension (optional)
concerned_item = '\"http://www.opensilex.org/demo/DMO2012-1\"' # str | Search by concerned item (optional)
status = '\"linked\"' # str | Search by status (optional)
sort_by_date = 'sort_by_date_example' # str | Sort results by date (optional)


try:
    # Get all documents metadata corresponding to the searched params given
    api_response = api_instance.get_documents_metadata_by_search(page_size=page_size, page=page, uri=uri, document_type=document_type, creator=creator, language=language, title=title, creation_date=creation_date, extension=extension, concerned_item=concerned_item, status=status, sort_by_date=sort_by_date)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DocumentsApi->get_documents_metadata_by_search: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page_size** | **int**| Number of elements per page (limited to 150000) | [optional] [default to 20]
 **page** | **int**| Current page number | [optional] [default to 0]
 **uri** | **str**| Search by URI | [optional] 
 **document_type** | **str**| Search by document type | [optional] 
 **creator** | **str**| Search by creator | [optional] 
 **language** | **str**| Search by language | [optional] 
 **title** | **str**| Search by title | [optional] 
 **creation_date** | **str**| Search by creation date | [optional] 
 **extension** | **str**| Search by extension | [optional] 
 **concerned_item** | **str**| Search by concerned item | [optional] 
 **status** | **str**| Search by status | [optional] 
 **sort_by_date** | **str**| Sort results by date | [optional] 


### Return type

[**list[DocumentMetadataDTO]**](DocumentMetadataDTO.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_documents_type**
> get_documents_type(authorization, page_size=page_size, page=page)

Get all documents types

Retrieve all documents types 

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.DocumentsApi(pythonClient)
page_size = 20 # int | Number of elements per page (limited to 150000) (optional) (default to 20)
page = 0 # int | Current page number (optional) (default to 0)


try:
    # Get all documents types
    api_instance.get_documents_type(page_size=page_size, page=page)
except ApiException as e:
    print("Exception when calling DocumentsApi->get_documents_type: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page_size** | **int**| Number of elements per page (limited to 150000) | [optional] [default to 20]
 **page** | **int**| Current page number | [optional] [default to 0]


### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post_document_file**
> ResponseFormPOST post_document_file(authorization, body=body, uri=uri)

Post data file

This can only be done by a PHIS-SILEX user. Not working from this documentation. Implement a client or use Postman application.

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.DocumentsApi(pythonClient)
body = '/path/to/file.txt' # file | File to upload (optional)
uri = 'uri_example' # str | URI given from \"/documents\" path for upload (optional)


try:
    # Post data file
    api_response = api_instance.post_document_file(body=body, uri=uri)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DocumentsApi->post_document_file: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | **file**| File to upload | [optional] 
 **uri** | **str**| URI given from \&quot;/documents\&quot; path for upload | [optional] 


### Return type

[**ResponseFormPOST**](ResponseFormPOST.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/octet-stream
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post_documents**
> list[DocumentMetadataDTO] post_documents(body, authorization)

Save a file

This can only be done by a PHIS-SILEX user.

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.DocumentsApi(pythonClient)
body = [WeisWSClient.DocumentMetadataDTO()] # list[DocumentMetadataDTO] | JSON Document metadata


try:
    # Save a file
    api_response = api_instance.post_documents(body, )
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DocumentsApi->post_documents: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**list[DocumentMetadataDTO]**](DocumentMetadataDTO.md)| JSON Document metadata | 


### Return type

[**list[DocumentMetadataDTO]**](DocumentMetadataDTO.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **put_document_metadata**
> ResponseFormPOST put_document_metadata(authorization, body=body)

Update document metadata



### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.DocumentsApi(pythonClient)
body = [WeisWSClient.DocumentMetadataDTO()] # list[DocumentMetadataDTO] | Json document metadata (optional)


try:
    # Update document metadata
    api_response = api_instance.put_document_metadata(body=body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DocumentsApi->put_document_metadata: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**list[DocumentMetadataDTO]**](DocumentMetadataDTO.md)| Json document metadata | [optional] 


### Return type

[**ResponseFormPOST**](ResponseFormPOST.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

