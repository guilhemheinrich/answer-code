# EventPostDTO

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**rdf_type** | **str** |  | 
**concerned_items_uris** | **list[str]** |  | 
**_date** | **str** |  | 
**properties** | [**list[PropertyDTO]**](PropertyDTO.md) |  | 
**description** | **str** |  | [optional] 
**creator** | **str** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


