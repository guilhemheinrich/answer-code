# WeisWSClient.ActuatorsApi

All URIs are relative to *http://www.opensilex.org:8080/weisAPI/rest*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_actuator_details**](ActuatorsApi.md#get_actuator_details) | **GET** /actuators/{uri} | Get an actuator
[**get_actuators_by_search**](ActuatorsApi.md#get_actuators_by_search) | **GET** /actuators | Get all actuators corresponding to the search params given
[**post**](ActuatorsApi.md#post) | **POST** /actuators | Post actuator(s)
[**put**](ActuatorsApi.md#put) | **PUT** /actuators | Put actuator(s)
[**put_measured_variables**](ActuatorsApi.md#put_measured_variables) | **PUT** /actuators/{uri}/variables | Update the measured variables of an actuator


# **get_actuator_details**
> list[ActuatorDetailDTO] get_actuator_details(uri, authorization, page_size=page_size, page=page)

Get an actuator

Retrieve an actuator. Need URL encoded actuator URI

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.ActuatorsApi(pythonClient)
uri = '\"http://www.opensilex.org/opensilex/2019/a19001\"' # str | An actuator URI (Unique Resource Identifier)
page_size = 20 # int | Number of elements per page (limited to 150000) (optional) (default to 20)
page = 0 # int | Current page number (optional) (default to 0)


try:
    # Get an actuator
    api_response = api_instance.get_actuator_details(uri, page_size=page_size, page=page)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ActuatorsApi->get_actuator_details: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **uri** | **str**| An actuator URI (Unique Resource Identifier) | 
 **page_size** | **int**| Number of elements per page (limited to 150000) | [optional] [default to 20]
 **page** | **int**| Current page number | [optional] [default to 0]


### Return type

[**list[ActuatorDetailDTO]**](ActuatorDetailDTO.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_actuators_by_search**
> list[ActuatorDTO] get_actuators_by_search(authorization, page_size=page_size, page=page, uri=uri, rdf_type=rdf_type, label=label, brand=brand, serial_number=serial_number, model=model, in_service_date=in_service_date, date_of_purchase=date_of_purchase, date_of_last_calibration=date_of_last_calibration, person_in_charge=person_in_charge)

Get all actuators corresponding to the search params given

Retrieve all actuators authorized for the user corresponding to the searched params given

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.ActuatorsApi(pythonClient)
page_size = 20 # int | Number of elements per page (limited to 150000) (optional) (default to 20)
page = 0 # int | Current page number (optional) (default to 0)
uri = '\"http://www.opensilex.org/opensilex/2019/a19001\"' # str | Search by uri (optional)
rdf_type = '\"http://www.opensilex.org/vocabulary/oeso#Sensor\"' # str | Search by type uri (optional)
label = '\"par03_p\"' # str | Search by label (optional)
brand = '\"Skye Instruments\"' # str | Search by brand (optional)
serial_number = '\"A1E345F32\"' # str | Search by serial number (optional)
model = '\"m001\"' # str | Search by model (optional)
in_service_date = '\"2017-06-15\"' # str | Search by service date (optional)
date_of_purchase = '\"2017-06-15\"' # str | Search by date of purchase (optional)
date_of_last_calibration = '\"2017-06-15\"' # str | Search by date of last calibration (optional)
person_in_charge = '\"admin@opensilex.org\"' # str | Search by person in charge (optional)


try:
    # Get all actuators corresponding to the search params given
    api_response = api_instance.get_actuators_by_search(page_size=page_size, page=page, uri=uri, rdf_type=rdf_type, label=label, brand=brand, serial_number=serial_number, model=model, in_service_date=in_service_date, date_of_purchase=date_of_purchase, date_of_last_calibration=date_of_last_calibration, person_in_charge=person_in_charge)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ActuatorsApi->get_actuators_by_search: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page_size** | **int**| Number of elements per page (limited to 150000) | [optional] [default to 20]
 **page** | **int**| Current page number | [optional] [default to 0]
 **uri** | **str**| Search by uri | [optional] 
 **rdf_type** | **str**| Search by type uri | [optional] 
 **label** | **str**| Search by label | [optional] 
 **brand** | **str**| Search by brand | [optional] 
 **serial_number** | **str**| Search by serial number | [optional] 
 **model** | **str**| Search by model | [optional] 
 **in_service_date** | **str**| Search by service date | [optional] 
 **date_of_purchase** | **str**| Search by date of purchase | [optional] 
 **date_of_last_calibration** | **str**| Search by date of last calibration | [optional] 
 **person_in_charge** | **str**| Search by person in charge | [optional] 


### Return type

[**list[ActuatorDTO]**](ActuatorDTO.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post**
> ResponseFormPOST post(authorization, body=body)

Post actuator(s)

Register actuator(s) in the database

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.ActuatorsApi(pythonClient)
body = [WeisWSClient.ActuatorPostDTO()] # list[ActuatorPostDTO] | JSON format to insert actuators (optional)


try:
    # Post actuator(s)
    api_response = api_instance.post(body=body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ActuatorsApi->post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**list[ActuatorPostDTO]**](ActuatorPostDTO.md)| JSON format to insert actuators | [optional] 


### Return type

[**ResponseFormPOST**](ResponseFormPOST.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **put**
> ResponseFormPOST put(authorization, body=body)

Put actuator(s)

Update actuator(s) in the database

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.ActuatorsApi(pythonClient)
body = [WeisWSClient.ActuatorDTO()] # list[ActuatorDTO] | JSON format to insert actuators (optional)


try:
    # Put actuator(s)
    api_response = api_instance.put(body=body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ActuatorsApi->put: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**list[ActuatorDTO]**](ActuatorDTO.md)| JSON format to insert actuators | [optional] 


### Return type

[**ResponseFormPOST**](ResponseFormPOST.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **put_measured_variables**
> ResponseFormPOST put_measured_variables(uri, authorization, body=body)

Update the measured variables of an actuator



### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.ActuatorsApi(pythonClient)
uri = '\"http://www.opensilex.org/opensilex/2019/a19001\"' # str | An actuator URI (Unique Resource Identifier)
body = [WeisWSClient.list[str]()] # list[str] | List of variables uris (optional)


try:
    # Update the measured variables of an actuator
    api_response = api_instance.put_measured_variables(uri, body=body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ActuatorsApi->put_measured_variables: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **uri** | **str**| An actuator URI (Unique Resource Identifier) | 
 **body** | **list[str]**| List of variables uris | [optional] 


### Return type

[**ResponseFormPOST**](ResponseFormPOST.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

