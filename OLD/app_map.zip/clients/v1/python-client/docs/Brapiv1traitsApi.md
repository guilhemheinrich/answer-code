# WeisWSClient.Brapiv1traitsApi

All URIs are relative to *http://www.opensilex.org:8080/weisAPI/rest*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_trait_details1**](Brapiv1traitsApi.md#get_trait_details1) | **GET** /brapi/v1/traits/{traitDbId} | Retrieve trait details by id
[**get_traits_list**](Brapiv1traitsApi.md#get_traits_list) | **GET** /brapi/v1/traits | Retrieve the list of all traits available in the system


# **get_trait_details1**
> list[BrapiTraitDTO] get_trait_details1(trait_db_id, authorization)

Retrieve trait details by id

Retrieve trait details by id

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.Brapiv1traitsApi(pythonClient)
trait_db_id = '\"http://www.opensilex.org/demo/id/traits/t001\"' # str | A trait URI (Unique Resource Identifier)


try:
    # Retrieve trait details by id
    api_response = api_instance.get_trait_details1(trait_db_id, )
    pprint(api_response)
except ApiException as e:
    print("Exception when calling Brapiv1traitsApi->get_trait_details1: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **trait_db_id** | **str**| A trait URI (Unique Resource Identifier) | 


### Return type

[**list[BrapiTraitDTO]**](BrapiTraitDTO.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_traits_list**
> list[BrapiTraitDTO] get_traits_list(authorization, page_size=page_size, page=page)

Retrieve the list of all traits available in the system

Retrieve the list of all traits available in the system

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.Brapiv1traitsApi(pythonClient)
page_size = 20 # int | Number of elements per page (limited to 150000) (optional) (default to 20)
page = 0 # int | Current page number (optional) (default to 0)


try:
    # Retrieve the list of all traits available in the system
    api_response = api_instance.get_traits_list(page_size=page_size, page=page)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling Brapiv1traitsApi->get_traits_list: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page_size** | **int**| Number of elements per page (limited to 150000) | [optional] [default to 20]
 **page** | **int**| Current page number | [optional] [default to 0]


### Return type

[**list[BrapiTraitDTO]**](BrapiTraitDTO.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

