# WeisWSClient.AnnotationsApi

All URIs are relative to *http://www.opensilex.org:8080/weisAPI/rest*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_annotation_by_uri**](AnnotationsApi.md#get_annotation_by_uri) | **GET** /annotations/{uri} | Get a annotation
[**get_annotations_by_search**](AnnotationsApi.md#get_annotations_by_search) | **GET** /annotations | Get all annotations corresponding to the search params given
[**post1**](AnnotationsApi.md#post1) | **POST** /annotations | Post annotations


# **get_annotation_by_uri**
> list[AnnotationDTO] get_annotation_by_uri(uri, authorization)

Get a annotation

Retrieve a annotation. Need URL encoded annotation URI

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.AnnotationsApi(pythonClient)
uri = '\"http://www.opensilex.org/demo/2018/s18001\"' # str | a sensor URI (Unique Resource Identifier)


try:
    # Get a annotation
    api_response = api_instance.get_annotation_by_uri(uri, )
    pprint(api_response)
except ApiException as e:
    print("Exception when calling AnnotationsApi->get_annotation_by_uri: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **uri** | **str**| a sensor URI (Unique Resource Identifier) | 


### Return type

[**list[AnnotationDTO]**](AnnotationDTO.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_annotations_by_search**
> list[AnnotationDTO] get_annotations_by_search(authorization, page_size=page_size, page=page, uri=uri, creator=creator, target=target, description=description, motivated_by=motivated_by, date_sort_asc=date_sort_asc)

Get all annotations corresponding to the search params given

Retrieve all annotations authorized for the user corresponding to the searched params given

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.AnnotationsApi(pythonClient)
page_size = 20 # int | Number of elements per page (limited to 150000) (optional) (default to 20)
page = 0 # int | Current page number (optional) (default to 0)
uri = '\"http://www.opensilex.org/platform/id/annotation/8247af37-769c-495b-8e7e-78b1141176c2\"' # str | Search by annotation uri (optional)
creator = '\"http://www.opensilex.org/demo/id/agent/marie_dupond\"' # str | Search by creator (optional)
target = '\"http://www.opensilex.org/demo/2018/o18000076\"' # str | Search by target (optional)
description = '\"Ustilago maydis infection\"' # str | Search by comment (optional)
motivated_by = '\"http://www.w3.org/ns/oa#commenting\"' # str | Search by motivation (optional)
date_sort_asc = true # bool | Date search result order ('true' for ascending and 'false' for descending) (optional)


try:
    # Get all annotations corresponding to the search params given
    api_response = api_instance.get_annotations_by_search(page_size=page_size, page=page, uri=uri, creator=creator, target=target, description=description, motivated_by=motivated_by, date_sort_asc=date_sort_asc)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling AnnotationsApi->get_annotations_by_search: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page_size** | **int**| Number of elements per page (limited to 150000) | [optional] [default to 20]
 **page** | **int**| Current page number | [optional] [default to 0]
 **uri** | **str**| Search by annotation uri | [optional] 
 **creator** | **str**| Search by creator | [optional] 
 **target** | **str**| Search by target | [optional] 
 **description** | **str**| Search by comment | [optional] 
 **motivated_by** | **str**| Search by motivation | [optional] 
 **date_sort_asc** | **bool**| Date search result order (&#39;true&#39; for ascending and &#39;false&#39; for descending) | [optional] 


### Return type

[**list[AnnotationDTO]**](AnnotationDTO.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post1**
> ResponseFormPOST post1(authorization, body=body)

Post annotations

Register new annotations in the triplestore

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.AnnotationsApi(pythonClient)
body = [WeisWSClient.AnnotationPostDTO()] # list[AnnotationPostDTO] | JSON format of an annotation (optional)


try:
    # Post annotations
    api_response = api_instance.post1(body=body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling AnnotationsApi->post1: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**list[AnnotationPostDTO]**](AnnotationPostDTO.md)| JSON format of an annotation | [optional] 


### Return type

[**ResponseFormPOST**](ResponseFormPOST.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

