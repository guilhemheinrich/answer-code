# MetadataFileUAVDTO

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**installation** | **str** |  | [optional] 
**group_plot_type** | **str** |  | [optional] 
**group_plot_alias** | **str** |  | [optional] 
**group_plot_uri** | **str** |  | [optional] 
**group_plot_species** | **str** |  | [optional] 
**pilot** | **str** |  | [optional] 
**camera_type** | **str** |  | [optional] 
**camera_alias** | **str** |  | [optional] 
**camera_uri** | **str** |  | [optional] 
**vector_type** | **str** |  | [optional] 
**vector_alias** | **str** |  | [optional] 
**vector_uri** | **str** |  | [optional] 
**radiometric_target_alias** | **str** |  | [optional] 
**radiometric_target_uri** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


