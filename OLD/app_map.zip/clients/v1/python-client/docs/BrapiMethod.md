# BrapiMethod

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**method_db_id** | **str** |  | [optional] 
**method_name** | **str** |  | [optional] 
**brapi_class** | **str** |  | [optional] 
**description** | **str** |  | [optional] 
**formula** | **str** |  | [optional] 
**ontology_reference** | **str** |  | [optional] 
**reference** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


