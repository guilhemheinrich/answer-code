# WeisWSClient.ApiApi

All URIs are relative to *http://www.opensilex.org:8080/weisAPI/rest*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_api_description**](ApiApi.md#get_api_description) | **GET** /api | Retrieve informations about OpenSILEX API


# **get_api_description**
> ApiDescriptionDTO get_api_description()

Retrieve informations about OpenSILEX API

Retreive version, name and major version number.

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.ApiApi(pythonClient)


try:
    # Retrieve informations about OpenSILEX API
    api_response = api_instance.get_api_description()
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ApiApi->get_api_description: %s\n" % e)
```

### Parameters
This endpoint does not need any parameter.


### Return type

[**ApiDescriptionDTO**](ApiDescriptionDTO.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

