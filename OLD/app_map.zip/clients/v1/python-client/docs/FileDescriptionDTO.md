# FileDescriptionDTO

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**uri** | **str** |  | [optional] 
**rdf_type** | **str** |  | [optional] 
**_date** | **str** |  | [optional] 
**concerned_items** | [**list[ConcernedItemDTO]**](ConcernedItemDTO.md) |  | [optional] 
**provenance_uri** | **str** |  | [optional] 
**metadata** | **dict(str, object)** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


