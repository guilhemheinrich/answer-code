# WeisWSClient.LayersApi

All URIs are relative to *http://www.opensilex.org:8080/weisAPI/rest*

Method | HTTP request | Description
------------- | ------------- | -------------
[**post_layer**](LayersApi.md#post_layer) | **POST** /layers | Post a layer


# **post_layer**
> ResponseFormPOST post_layer(authorization, body=body)

Post a layer

Create a geojson layer file

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.LayersApi(pythonClient)
body = [WeisWSClient.LayerDTO()] # list[LayerDTO] | JSON format of requested layer (optional)


try:
    # Post a layer
    api_response = api_instance.post_layer(body=body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling LayersApi->post_layer: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**list[LayerDTO]**](LayerDTO.md)| JSON format of requested layer | [optional] 


### Return type

[**ResponseFormPOST**](ResponseFormPOST.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

