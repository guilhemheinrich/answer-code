# WeisWSClient.UriApi

All URIs are relative to *http://www.opensilex.org:8080/weisAPI/rest*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_ancestors**](UriApi.md#get_ancestors) | **GET** /uri/{uri}/ancestors | Get all the ancestor of an uri
[**get_descendants**](UriApi.md#get_descendants) | **GET** /uri/{uri}/descendants | Get all the descendants of an uri
[**get_instances_by_concept**](UriApi.md#get_instances_by_concept) | **GET** /uri/{uri}/instances | Get all the instances of a concept
[**get_sibblings**](UriApi.md#get_sibblings) | **GET** /uri/{uri}/siblings | Get all the siblings of an Uri
[**get_type_if_uri_exist**](UriApi.md#get_type_if_uri_exist) | **GET** /uri/{uri}/type | get the type of an uri if it exist
[**get_uri_metadata**](UriApi.md#get_uri_metadata) | **GET** /uri/{uri} | Get all uri informations
[**get_uris_by_label**](UriApi.md#get_uris_by_label) | **GET** /uri | get all uri with a given label
[**is_uri_existing**](UriApi.md#is_uri_existing) | **GET** /uri/{uri}/exist | check if an uri exists or not (in the triplestore)


# **get_ancestors**
> list[Uri] get_ancestors(uri, authorization, page_size=page_size, page=page)

Get all the ancestor of an uri

Retrieve all Class parents of the uri

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.UriApi(pythonClient)
uri = '\"http://www.opensilex.org/vocabulary/oeso#Document\"' # str | A concept URI (Unique Resource Identifier)
page_size = 20 # int | Number of elements per page (limited to 150000) (optional) (default to 20)
page = 0 # int | Current page number (optional) (default to 0)


try:
    # Get all the ancestor of an uri
    api_response = api_instance.get_ancestors(uri, page_size=page_size, page=page)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling UriApi->get_ancestors: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **uri** | **str**| A concept URI (Unique Resource Identifier) | 
 **page_size** | **int**| Number of elements per page (limited to 150000) | [optional] [default to 20]
 **page** | **int**| Current page number | [optional] [default to 0]


### Return type

[**list[Uri]**](Uri.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_descendants**
> list[Uri] get_descendants(uri, authorization, page_size=page_size, page=page)

Get all the descendants of an uri

Retrieve all subclass and the subClass of subClass too

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.UriApi(pythonClient)
uri = '\"http://www.opensilex.org/vocabulary/oeso#Document\"' # str | A concept URI (Unique Resource Identifier)
page_size = 20 # int | Number of elements per page (limited to 150000) (optional) (default to 20)
page = 0 # int | Current page number (optional) (default to 0)


try:
    # Get all the descendants of an uri
    api_response = api_instance.get_descendants(uri, page_size=page_size, page=page)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling UriApi->get_descendants: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **uri** | **str**| A concept URI (Unique Resource Identifier) | 
 **page_size** | **int**| Number of elements per page (limited to 150000) | [optional] [default to 20]
 **page** | **int**| Current page number | [optional] [default to 0]


### Return type

[**list[Uri]**](Uri.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_instances_by_concept**
> list[Uri] get_instances_by_concept(uri, authorization, deep=deep, language=language, page_size=page_size, page=page)

Get all the instances of a concept

Retrieve all instances of subClass too, if deep = true

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.UriApi(pythonClient)
uri = '\"http://www.opensilex.org/vocabulary/oeso#Document\"' # str | A concept URI (Unique Resource Identifier)
deep = true # bool | true or false deppending if you want instances of concept progenity (optional) (default to true)
language = 'en' # str | true or false deppending if you want instances of concept progenity (optional) (default to en)
page_size = 20 # int | Number of elements per page (limited to 150000) (optional) (default to 20)
page = 0 # int | Current page number (optional) (default to 0)


try:
    # Get all the instances of a concept
    api_response = api_instance.get_instances_by_concept(uri, deep=deep, language=language, page_size=page_size, page=page)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling UriApi->get_instances_by_concept: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **uri** | **str**| A concept URI (Unique Resource Identifier) | 
 **deep** | **bool**| true or false deppending if you want instances of concept progenity | [optional] [default to true]
 **language** | **str**| true or false deppending if you want instances of concept progenity | [optional] [default to en]
 **page_size** | **int**| Number of elements per page (limited to 150000) | [optional] [default to 20]
 **page** | **int**| Current page number | [optional] [default to 0]


### Return type

[**list[Uri]**](Uri.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_sibblings**
> list[Uri] get_sibblings(uri, authorization, page_size=page_size, page=page)

Get all the siblings of an Uri

Retrieve all Class with same parent

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.UriApi(pythonClient)
uri = '\"http://www.opensilex.org/vocabulary/oeso#ScientificDocument\"' # str | A concept URI (Unique Resource Identifier)
page_size = 20 # int | Number of elements per page (limited to 150000) (optional) (default to 20)
page = 0 # int | Current page number (optional) (default to 0)


try:
    # Get all the siblings of an Uri
    api_response = api_instance.get_sibblings(uri, page_size=page_size, page=page)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling UriApi->get_sibblings: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **uri** | **str**| A concept URI (Unique Resource Identifier) | 
 **page_size** | **int**| Number of elements per page (limited to 150000) | [optional] [default to 20]
 **page** | **int**| Current page number | [optional] [default to 0]


### Return type

[**list[Uri]**](Uri.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_type_if_uri_exist**
> list[Uri] get_type_if_uri_exist(uri, authorization)

get the type of an uri if it exist



### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.UriApi(pythonClient)
uri = '\"http://www.opensilex.org/vocabulary/oeso#Document\"' # str | A concept URI (Unique Resource Identifier)


try:
    # get the type of an uri if it exist
    api_response = api_instance.get_type_if_uri_exist(uri, )
    pprint(api_response)
except ApiException as e:
    print("Exception when calling UriApi->get_type_if_uri_exist: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **uri** | **str**| A concept URI (Unique Resource Identifier) | 


### Return type

[**list[Uri]**](Uri.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_uri_metadata**
> list[Uri] get_uri_metadata(uri, authorization, page_size=page_size, page=page)

Get all uri informations

Retrieve all infos of the uri

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.UriApi(pythonClient)
uri = '\"http://www.opensilex.org/vocabulary/oeso#Document\"' # str | Search by uri
page_size = 20 # int | Number of elements per page (limited to 150000) (optional) (default to 20)
page = 0 # int | Current page number (optional) (default to 0)


try:
    # Get all uri informations
    api_response = api_instance.get_uri_metadata(uri, page_size=page_size, page=page)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling UriApi->get_uri_metadata: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **uri** | **str**| Search by uri | 
 **page_size** | **int**| Number of elements per page (limited to 150000) | [optional] [default to 20]
 **page** | **int**| Current page number | [optional] [default to 0]


### Return type

[**list[Uri]**](Uri.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_uris_by_label**
> list[Uri] get_uris_by_label(label, authorization, page_size=page_size, page=page)

get all uri with a given label

Retrieve all uri from the label given

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.UriApi(pythonClient)
label = '\"'document'@en\"' # str | Search by label
page_size = 20 # int | Number of elements per page (limited to 150000) (optional) (default to 20)
page = 0 # int | Current page number (optional) (default to 0)


try:
    # get all uri with a given label
    api_response = api_instance.get_uris_by_label(label, page_size=page_size, page=page)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling UriApi->get_uris_by_label: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **label** | **str**| Search by label | 
 **page_size** | **int**| Number of elements per page (limited to 150000) | [optional] [default to 20]
 **page** | **int**| Current page number | [optional] [default to 0]


### Return type

[**list[Uri]**](Uri.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **is_uri_existing**
> list[Ask] is_uri_existing(uri, authorization)

check if an uri exists or not (in the triplestore)

Return a boolean

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.UriApi(pythonClient)
uri = '\"http://www.opensilex.org/vocabulary/oeso#Document\"' # str | A concept URI (Unique Resource Identifier)


try:
    # check if an uri exists or not (in the triplestore)
    api_response = api_instance.is_uri_existing(uri, )
    pprint(api_response)
except ApiException as e:
    print("Exception when calling UriApi->is_uri_existing: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **uri** | **str**| A concept URI (Unique Resource Identifier) | 


### Return type

[**list[Ask]**](Ask.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

