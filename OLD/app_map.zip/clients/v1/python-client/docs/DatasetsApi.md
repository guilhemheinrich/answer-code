# WeisWSClient.DatasetsApi

All URIs are relative to *http://www.opensilex.org:8080/weisAPI/rest*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_data_by_search**](DatasetsApi.md#get_data_by_search) | **GET** /datasets | Get all data corresponding to the search params given
[**post_dataset_data**](DatasetsApi.md#post_dataset_data) | **POST** /datasets | Post dataset


# **get_data_by_search**
> list[Dataset] get_data_by_search(authorization, page_size=page_size, page=page, experiment=experiment, variable=variable, agronomical_objects=agronomical_objects, start_date=start_date, end_date=end_date, sensor=sensor, incertitude=incertitude)

Get all data corresponding to the search params given



### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.DatasetsApi(pythonClient)
page_size = 20 # int | Number of elements per page (limited to 150000) (optional) (default to 20)
page = 0 # int | Current page number (optional) (default to 0)
experiment = '\"http://www.opensilex.org/demo/DMO2012-1\"' # str | Search by experiment (optional)
variable = '\"http://www.opensilex.org/demo/id/variable/v0000001\"' # str | Search by variable (optional)
agronomical_objects = '\"http://www.opensilex.org/demo/2018/o18000076,http://www.opensilex.org/demo/2018/o18000076\"' # str | Search by agronomical(s) object(s), separated by coma (optional)
start_date = '\"2017-06-15 10:51:00+0200\"' # str | Search by interval - Start date (optional)
end_date = '\"2017-06-15 10:51:00+0200\"' # str | Search by interval - End date (optional)
sensor = '\"http://www.opensilex.org/demo/2018/s18001\"' # str | Search by sensor (optional)
incertitude = '\"0.4\"' # str | Search by incertitude (optional)


try:
    # Get all data corresponding to the search params given
    api_response = api_instance.get_data_by_search(page_size=page_size, page=page, experiment=experiment, variable=variable, agronomical_objects=agronomical_objects, start_date=start_date, end_date=end_date, sensor=sensor, incertitude=incertitude)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DatasetsApi->get_data_by_search: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page_size** | **int**| Number of elements per page (limited to 150000) | [optional] [default to 20]
 **page** | **int**| Current page number | [optional] [default to 0]
 **experiment** | **str**| Search by experiment | [optional] 
 **variable** | **str**| Search by variable | [optional] 
 **agronomical_objects** | **str**| Search by agronomical(s) object(s), separated by coma | [optional] 
 **start_date** | **str**| Search by interval - Start date | [optional] 
 **end_date** | **str**| Search by interval - End date | [optional] 
 **sensor** | **str**| Search by sensor | [optional] 
 **incertitude** | **str**| Search by incertitude | [optional] 


### Return type

[**list[Dataset]**](Dataset.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post_dataset_data**
> ResponseFormPOST post_dataset_data(body, authorization)

Post dataset



### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.DatasetsApi(pythonClient)
body = [WeisWSClient.DatasetDTO()] # list[DatasetDTO] | JSON format of raw data


try:
    # Post dataset
    api_response = api_instance.post_dataset_data(body, )
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DatasetsApi->post_dataset_data: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**list[DatasetDTO]**](DatasetDTO.md)| JSON format of raw data | 


### Return type

[**ResponseFormPOST**](ResponseFormPOST.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

