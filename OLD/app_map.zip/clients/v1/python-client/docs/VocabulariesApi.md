# WeisWSClient.VocabulariesApi

All URIs are relative to *http://www.opensilex.org:8080/weisAPI/rest*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_contacts**](VocabulariesApi.md#get_contacts) | **GET** /vocabularies/contacts/properties | Get all contact properties that can be added to a given rdfType
[**get_device_properties**](VocabulariesApi.md#get_device_properties) | **GET** /vocabularies/devices/properties | Get all device properties that can be added to a given rdfType
[**get_namespaces**](VocabulariesApi.md#get_namespaces) | **GET** /vocabularies/namespaces | Get all triplestore namespaces
[**get_rdfs**](VocabulariesApi.md#get_rdfs) | **GET** /vocabularies/rdfs/properties | Get all rdfs properties that can be added to an instance


# **get_contacts**
> list[ModelProperty] get_contacts(authorization, rdf_type=rdf_type, page_size=page_size, page=page)

Get all contact properties that can be added to a given rdfType

Retrieve all contact properties authorized

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.VocabulariesApi(pythonClient)
rdf_type = '\"http://www.opensilex.org/vocabulary/oeso#Sensor\"' # str | Search by rdfType (optional)
page_size = 20 # int | Number of elements per page (limited to 150000) (optional) (default to 20)
page = 0 # int | Current page number (optional) (default to 0)


try:
    # Get all contact properties that can be added to a given rdfType
    api_response = api_instance.get_contacts(rdf_type=rdf_type, page_size=page_size, page=page)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling VocabulariesApi->get_contacts: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **rdf_type** | **str**| Search by rdfType | [optional] 
 **page_size** | **int**| Number of elements per page (limited to 150000) | [optional] [default to 20]
 **page** | **int**| Current page number | [optional] [default to 0]


### Return type

[**list[ModelProperty]**](ModelProperty.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_device_properties**
> list[ModelProperty] get_device_properties(authorization, rdf_type=rdf_type, page_size=page_size, page=page)

Get all device properties that can be added to a given rdfType

Retrieve all device properties authorized

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.VocabulariesApi(pythonClient)
rdf_type = '\"http://www.opensilex.org/vocabulary/oeso#Sensor\"' # str | Search by rdfType (optional)
page_size = 20 # int | Number of elements per page (limited to 150000) (optional) (default to 20)
page = 0 # int | Current page number (optional) (default to 0)


try:
    # Get all device properties that can be added to a given rdfType
    api_response = api_instance.get_device_properties(rdf_type=rdf_type, page_size=page_size, page=page)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling VocabulariesApi->get_device_properties: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **rdf_type** | **str**| Search by rdfType | [optional] 
 **page_size** | **int**| Number of elements per page (limited to 150000) | [optional] [default to 20]
 **page** | **int**| Current page number | [optional] [default to 0]


### Return type

[**list[ModelProperty]**](ModelProperty.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_namespaces**
> list[ModelProperty] get_namespaces(authorization, page_size=page_size, page=page)

Get all triplestore namespaces

Retrieve all triplestore namespaces

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.VocabulariesApi(pythonClient)
page_size = 20 # int | Number of elements per page (limited to 150000) (optional) (default to 20)
page = 0 # int | Current page number (optional) (default to 0)


try:
    # Get all triplestore namespaces
    api_response = api_instance.get_namespaces(page_size=page_size, page=page)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling VocabulariesApi->get_namespaces: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page_size** | **int**| Number of elements per page (limited to 150000) | [optional] [default to 20]
 **page** | **int**| Current page number | [optional] [default to 0]


### Return type

[**list[ModelProperty]**](ModelProperty.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_rdfs**
> list[ModelProperty] get_rdfs(authorization, page_size=page_size, page=page)

Get all rdfs properties that can be added to an instance

Retrieve all rdfs properties authorized

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.VocabulariesApi(pythonClient)
page_size = 20 # int | Number of elements per page (limited to 150000) (optional) (default to 20)
page = 0 # int | Current page number (optional) (default to 0)


try:
    # Get all rdfs properties that can be added to an instance
    api_response = api_instance.get_rdfs(page_size=page_size, page=page)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling VocabulariesApi->get_rdfs: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page_size** | **int**| Number of elements per page (limited to 150000) | [optional] [default to 20]
 **page** | **int**| Current page number | [optional] [default to 0]


### Return type

[**list[ModelProperty]**](ModelProperty.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

