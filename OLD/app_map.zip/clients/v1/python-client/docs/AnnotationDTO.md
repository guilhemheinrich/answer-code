# AnnotationDTO

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**creator** | **str** |  | 
**motivated_by** | **str** |  | 
**body_values** | **list[str]** |  | [optional] 
**targets** | **list[str]** |  | 
**uri** | **str** |  | [optional] 
**creation_date** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


