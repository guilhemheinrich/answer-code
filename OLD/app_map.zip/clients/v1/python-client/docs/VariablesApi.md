# WeisWSClient.VariablesApi

All URIs are relative to *http://www.opensilex.org:8080/weisAPI/rest*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_variable_detail**](VariablesApi.md#get_variable_detail) | **GET** /variables/{variable} | Get a variable
[**get_variables_by_search**](VariablesApi.md#get_variables_by_search) | **GET** /variables | Get all variables corresponding to the searched params given
[**get_variables_details_by_search**](VariablesApi.md#get_variables_details_by_search) | **GET** /variables/details | Get all variables details corresponding to the searched params given
[**post_variable**](VariablesApi.md#post_variable) | **POST** /variables | Post variable(s)
[**put_variable**](VariablesApi.md#put_variable) | **PUT** /variables | Update variable


# **get_variable_detail**
> list[Variable] get_variable_detail(variable, authorization, page_size=page_size, page=page)

Get a variable

Retrieve a variable. Need URL encoded variable URI (Unique resource identifier).

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.VariablesApi(pythonClient)
variable = '\"http://www.opensilex.org/demo/id/variable/v0000001\"' # str | A variable URI (Unique Resource Identifier)
page_size = 20 # int | Number of elements per page (limited to 150000) (optional) (default to 20)
page = 0 # int | Current page number (optional) (default to 0)


try:
    # Get a variable
    api_response = api_instance.get_variable_detail(variable, page_size=page_size, page=page)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling VariablesApi->get_variable_detail: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **variable** | **str**| A variable URI (Unique Resource Identifier) | 
 **page_size** | **int**| Number of elements per page (limited to 150000) | [optional] [default to 20]
 **page** | **int**| Current page number | [optional] [default to 0]


### Return type

[**list[Variable]**](Variable.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_variables_by_search**
> list[Variable] get_variables_by_search(authorization, page_size=page_size, page=page, uri=uri, label=label, trait=trait, trait_s_kos_reference=trait_s_kos_reference, method=method, unit=unit)

Get all variables corresponding to the searched params given

Retrieve all variables authorized for the user corresponding to the user corresponding to the searched params given

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.VariablesApi(pythonClient)
page_size = 20 # int | Number of elements per page (limited to 150000) (optional) (default to 20)
page = 0 # int | Current page number (optional) (default to 0)
uri = '\"http://www.opensilex.org/demo/id/variable/v0000001\"' # str | Search by URI (optional)
label = '\"LAI\"' # str | Search by label (optional)
trait = '\"http://www.opensilex.org/demo/id/traits/t001\"' # str | Search by trait (optional)
trait_s_kos_reference = '\"http://purl.obolibrary.org/obo/CO_125_0000002\"' # str | Search by skos trait reference (optional)
method = '\"http://www.opensilex.org/demo/id/methods/m001\"' # str | Search by method (optional)
unit = '\"http://www.opensilex.org/demo/id/units/u001\"' # str | Search by unit (optional)


try:
    # Get all variables corresponding to the searched params given
    api_response = api_instance.get_variables_by_search(page_size=page_size, page=page, uri=uri, label=label, trait=trait, trait_s_kos_reference=trait_s_kos_reference, method=method, unit=unit)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling VariablesApi->get_variables_by_search: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page_size** | **int**| Number of elements per page (limited to 150000) | [optional] [default to 20]
 **page** | **int**| Current page number | [optional] [default to 0]
 **uri** | **str**| Search by URI | [optional] 
 **label** | **str**| Search by label | [optional] 
 **trait** | **str**| Search by trait | [optional] 
 **trait_s_kos_reference** | **str**| Search by skos trait reference | [optional] 
 **method** | **str**| Search by method | [optional] 
 **unit** | **str**| Search by unit | [optional] 


### Return type

[**list[Variable]**](Variable.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_variables_details_by_search**
> list[Variable] get_variables_details_by_search(authorization, page_size=page_size, page=page, uri=uri, label=label, trait=trait, trait_s_kos_reference=trait_s_kos_reference, method=method, unit=unit)

Get all variables details corresponding to the searched params given

Retrieve all variables with details authorized for the user corresponding to the user corresponding to the searched params given

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.VariablesApi(pythonClient)
page_size = 20 # int | Number of elements per page (limited to 150000) (optional) (default to 20)
page = 0 # int | Current page number (optional) (default to 0)
uri = '\"http://www.opensilex.org/demo/id/variable/v0000001\"' # str | Search by URI (optional)
label = '\"LAI\"' # str | Search by label (optional)
trait = '\"http://www.opensilex.org/demo/id/traits/t001\"' # str | Search by trait (optional)
trait_s_kos_reference = '\"http://purl.obolibrary.org/obo/CO_125_0000002\"' # str | Search by skos trait reference (optional)
method = '\"http://www.opensilex.org/demo/id/methods/m001\"' # str | Search by method (optional)
unit = '\"http://www.opensilex.org/demo/id/units/u001\"' # str | Search by unit (optional)


try:
    # Get all variables details corresponding to the searched params given
    api_response = api_instance.get_variables_details_by_search(page_size=page_size, page=page, uri=uri, label=label, trait=trait, trait_s_kos_reference=trait_s_kos_reference, method=method, unit=unit)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling VariablesApi->get_variables_details_by_search: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page_size** | **int**| Number of elements per page (limited to 150000) | [optional] [default to 20]
 **page** | **int**| Current page number | [optional] [default to 0]
 **uri** | **str**| Search by URI | [optional] 
 **label** | **str**| Search by label | [optional] 
 **trait** | **str**| Search by trait | [optional] 
 **trait_s_kos_reference** | **str**| Search by skos trait reference | [optional] 
 **method** | **str**| Search by method | [optional] 
 **unit** | **str**| Search by unit | [optional] 


### Return type

[**list[Variable]**](Variable.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post_variable**
> ResponseFormPOST post_variable(authorization, body=body)

Post variable(s)

Register new variable(s) in the data base

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.VariablesApi(pythonClient)
body = [WeisWSClient.VariableDTO()] # list[VariableDTO] | JSON format of variable data (optional)


try:
    # Post variable(s)
    api_response = api_instance.post_variable(body=body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling VariablesApi->post_variable: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**list[VariableDTO]**](VariableDTO.md)| JSON format of variable data | [optional] 


### Return type

[**ResponseFormPOST**](ResponseFormPOST.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **put_variable**
> ResponseFormPOST put_variable(authorization, body=body)

Update variable



### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.VariablesApi(pythonClient)
body = [WeisWSClient.VariableDTO()] # list[VariableDTO] | JSON format of variable data (optional)


try:
    # Update variable
    api_response = api_instance.put_variable(body=body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling VariablesApi->put_variable: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**list[VariableDTO]**](VariableDTO.md)| JSON format of variable data | [optional] 


### Return type

[**ResponseFormPOST**](ResponseFormPOST.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

