# WeisWSClient.RadiometricTargetsApi

All URIs are relative to *http://www.opensilex.org:8080/weisAPI/rest*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_radiometric_targets_by_search**](RadiometricTargetsApi.md#get_radiometric_targets_by_search) | **GET** /radiometricTargets | Get all radiometric targets corresponding to the search params given
[**get_radiometric_targets_details**](RadiometricTargetsApi.md#get_radiometric_targets_details) | **GET** /radiometricTargets/{uri} | Get all radiometric target&#39;s details corresponding to the search uri
[**post_radiometric_targets**](RadiometricTargetsApi.md#post_radiometric_targets) | **POST** /radiometricTargets | Post radiometric(s) target(s) 
[**put4**](RadiometricTargetsApi.md#put4) | **PUT** /radiometricTargets | Update radiometric targets


# **get_radiometric_targets_by_search**
> list[RdfResourceDefinitionDTO] get_radiometric_targets_by_search(authorization, page_size=page_size, page=page, uri=uri, label=label)

Get all radiometric targets corresponding to the search params given

Retrieve all radiometric targets authorized for the user corresponding to the searched params given

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.RadiometricTargetsApi(pythonClient)
page_size = 20 # int | Number of elements per page (limited to 150000) (optional) (default to 20)
page = 0 # int | Current page number (optional) (default to 0)
uri = '\"http://www.opensilex.org/demo\"' # str | Search by uri (optional)
label = '\"EMPHASIS\"' # str | Search by label (optional)


try:
    # Get all radiometric targets corresponding to the search params given
    api_response = api_instance.get_radiometric_targets_by_search(page_size=page_size, page=page, uri=uri, label=label)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling RadiometricTargetsApi->get_radiometric_targets_by_search: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page_size** | **int**| Number of elements per page (limited to 150000) | [optional] [default to 20]
 **page** | **int**| Current page number | [optional] [default to 0]
 **uri** | **str**| Search by uri | [optional] 
 **label** | **str**| Search by label | [optional] 


### Return type

[**list[RdfResourceDefinitionDTO]**](RdfResourceDefinitionDTO.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_radiometric_targets_details**
> list[RdfResourceDefinitionDTO] get_radiometric_targets_details(uri, authorization)

Get all radiometric target's details corresponding to the search uri

Retrieve all radiometric target's details authorized for the user corresponding to the searched uri

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.RadiometricTargetsApi(pythonClient)
uri = '\"http://www.opensilex.org/demo\"' # str | An infrastructure URI (Unique Resource Identifier)


try:
    # Get all radiometric target's details corresponding to the search uri
    api_response = api_instance.get_radiometric_targets_details(uri, )
    pprint(api_response)
except ApiException as e:
    print("Exception when calling RadiometricTargetsApi->get_radiometric_targets_details: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **uri** | **str**| An infrastructure URI (Unique Resource Identifier) | 


### Return type

[**list[RdfResourceDefinitionDTO]**](RdfResourceDefinitionDTO.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post_radiometric_targets**
> ResponseFormPOST post_radiometric_targets(authorization, body=body)

Post radiometric(s) target(s) 

Register radiometric(s) target(s) in the database

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.RadiometricTargetsApi(pythonClient)
body = [WeisWSClient.RadiometricTargetPostDTO()] # list[RadiometricTargetPostDTO] | JSON format of radiometric target data (optional)


try:
    # Post radiometric(s) target(s) 
    api_response = api_instance.post_radiometric_targets(body=body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling RadiometricTargetsApi->post_radiometric_targets: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**list[RadiometricTargetPostDTO]**](RadiometricTargetPostDTO.md)| JSON format of radiometric target data | [optional] 


### Return type

[**ResponseFormPOST**](ResponseFormPOST.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **put4**
> ResponseFormPOST put4(authorization, body=body)

Update radiometric targets



### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.RadiometricTargetsApi(pythonClient)
body = [WeisWSClient.RadiometricTargetDTO()] # list[RadiometricTargetDTO] | JSON format of radiometric target data (optional)


try:
    # Update radiometric targets
    api_response = api_instance.put4(body=body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling RadiometricTargetsApi->put4: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**list[RadiometricTargetDTO]**](RadiometricTargetDTO.md)| JSON format of radiometric target data | [optional] 


### Return type

[**ResponseFormPOST**](ResponseFormPOST.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

