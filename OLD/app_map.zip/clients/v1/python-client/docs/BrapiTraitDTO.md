# BrapiTraitDTO

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**default_value** | **str** |  | [optional] 
**description** | **str** |  | [optional] 
**trait_name** | **str** |  | [optional] 
**observation_variables** | **list[str]** |  | [optional] 
**trait_id** | **str** |  | [optional] 
**trait_db_id** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


