# ImageMetadataDTO

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**rdf_type** | **str** |  | [optional] 
**concerned_items** | [**list[ConcernedItemDTO]**](ConcernedItemDTO.md) |  | [optional] 
**configuration** | [**ShootingConfigurationDTO**](ShootingConfigurationDTO.md) |  | [optional] 
**file_info** | [**FileInformationDTO**](FileInformationDTO.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


