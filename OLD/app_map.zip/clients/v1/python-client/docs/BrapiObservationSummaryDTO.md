# BrapiObservationSummaryDTO

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**collector** | **str** |  | [optional] 
**observation_db_id** | **str** |  | [optional] 
**observation_time_stamp** | **str** |  | [optional] 
**observation_variable_db_id** | **str** |  | [optional] 
**observation_variable_name** | **str** |  | [optional] 
**season** | **str** |  | [optional] 
**value** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


