# WeisWSClient.AcquisitionSessionsApi

All URIs are relative to *http://www.opensilex.org:8080/weisAPI/rest*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get4_p_metadata_file**](AcquisitionSessionsApi.md#get4_p_metadata_file) | **GET** /acquisitionSessions/metadataFile | Get the metadata for the acquisition session file


# **get4_p_metadata_file**
> list[MetadataFileUAVDTO] get4_p_metadata_file(vector_rdf_type, authorization, page_size=page_size, page=page)

Get the metadata for the acquisition session file

Retrieve the metadata for the acquisition session file. Need URL encoded of the vector type of the acquisition session (uav or drone)

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.AcquisitionSessionsApi(pythonClient)
vector_rdf_type = '\"http://www.opensilex.org/vocabulary/oeso#UAV\"' # str | A vector rdf type URI
page_size = 20 # int | Number of elements per page (limited to 150000) (optional) (default to 20)
page = 0 # int | Current page number (optional) (default to 0)


try:
    # Get the metadata for the acquisition session file
    api_response = api_instance.get4_p_metadata_file(vector_rdf_type, page_size=page_size, page=page)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling AcquisitionSessionsApi->get4_p_metadata_file: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **vector_rdf_type** | **str**| A vector rdf type URI | 
 **page_size** | **int**| Number of elements per page (limited to 150000) | [optional] [default to 20]
 **page** | **int**| Current page number | [optional] [default to 0]


### Return type

[**list[MetadataFileUAVDTO]**](MetadataFileUAVDTO.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

