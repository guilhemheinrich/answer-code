# WeisWSClient.DataApi

All URIs are relative to *http://www.opensilex.org:8080/weisAPI/rest*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_data**](DataApi.md#get_data) | **GET** /data | Get data corresponding to the search parameters given.
[**get_data_file**](DataApi.md#get_data_file) | **GET** /data/file/{fileUri} | Get data file
[**get_data_file_description**](DataApi.md#get_data_file_description) | **GET** /data/file/{fileUri}/description | Get data file description
[**get_data_file_descriptions_by_search**](DataApi.md#get_data_file_descriptions_by_search) | **GET** /data/file/search | Retrieve data file descriptions corresponding to the search parameters given.
[**get_data_search**](DataApi.md#get_data_search) | **GET** /data/search | Get data corresponding to the search parameters given.
[**post_data**](DataApi.md#post_data) | **POST** /data | Post data
[**post_data_file**](DataApi.md#post_data_file) | **POST** /data/file | Post data file
[**post_data_file_path**](DataApi.md#post_data_file_path) | **POST** /data/files | Post data file


# **get_data**
> list[Data] get_data(variable, authorization, page_size=page_size, page=page, start_date=start_date, end_date=end_date, object=object, provenance=provenance, date_sort_asc=date_sort_asc)

Get data corresponding to the search parameters given.

Retrieve all data corresponding to the search parameters given,<br/>Date parameters could be either a datetime like: 2017-06-15T10:51:00+0200<br/>or simply a date like: 2017-06-15

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.DataApi(pythonClient)
variable = '\"http://www.opensilex.org/demo/id/variable/v0000001\"' # str | Search by variable uri
page_size = 20 # int | Number of elements per page (limited to 150000) (optional) (default to 20)
page = 0 # int | Current page number (optional) (default to 0)
start_date = '\"2017-06-15T10:51:00+0200\"' # str | Search by minimal date (optional)
end_date = '\"2017-06-15T10:51:00+0200\"' # str | Search by maximal date (optional)
object = '\"http://www.opensilex.org/demo/2018/s18001\"' # str | Search by object uri (optional)
provenance = '\"http://www.opensilex.org/demo/2018/pv181515071552\"' # str | Search by provenance uri (optional)
date_sort_asc = true # bool | Date search result order ('true' for ascending and 'false' for descending) (optional)


try:
    # Get data corresponding to the search parameters given.
    api_response = api_instance.get_data(variable, page_size=page_size, page=page, start_date=start_date, end_date=end_date, object=object, provenance=provenance, date_sort_asc=date_sort_asc)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DataApi->get_data: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **variable** | **str**| Search by variable uri | 
 **page_size** | **int**| Number of elements per page (limited to 150000) | [optional] [default to 20]
 **page** | **int**| Current page number | [optional] [default to 0]
 **start_date** | **str**| Search by minimal date | [optional] 
 **end_date** | **str**| Search by maximal date | [optional] 
 **object** | **str**| Search by object uri | [optional] 
 **provenance** | **str**| Search by provenance uri | [optional] 
 **date_sort_asc** | **bool**| Date search result order (&#39;true&#39; for ascending and &#39;false&#39; for descending) | [optional] 


### Return type

[**list[Data]**](Data.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_data_file**
> get_data_file(file_uri)

Get data file



### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.DataApi(pythonClient)
file_uri = '\"http://www.opensilex.org/demo/DMO2012-1\"' # str | Search by fileUri


try:
    # Get data file
    api_instance.get_data_file(file_uri)
except ApiException as e:
    print("Exception when calling DataApi->get_data_file: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **file_uri** | **str**| Search by fileUri | 


### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/octet-stream

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_data_file_description**
> FileDescriptionDTO get_data_file_description(file_uri, authorization)

Get data file description



### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.DataApi(pythonClient)
file_uri = '\"http://www.opensilex.org/demo/DMO2012-1\"' # str | Search by fileUri


try:
    # Get data file description
    api_response = api_instance.get_data_file_description(file_uri, )
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DataApi->get_data_file_description: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **file_uri** | **str**| Search by fileUri | 


### Return type

[**FileDescriptionDTO**](FileDescriptionDTO.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_data_file_descriptions_by_search**
> list[FileDescriptionDTO] get_data_file_descriptions_by_search(rdf_type, authorization, page_size=page_size, page=page, start_date=start_date, end_date=end_date, provenance=provenance, concerned_items=concerned_items, json_value_filter=json_value_filter, date_sort_asc=date_sort_asc)

Retrieve data file descriptions corresponding to the search parameters given.



### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.DataApi(pythonClient)
rdf_type = '\"http://www.opensilex.org/demo/id/variable/v0000001\"' # str | Search by rdf type uri
page_size = 20 # int | Number of elements per page (limited to 150000) (optional) (default to 20)
page = 0 # int | Current page number (optional) (default to 0)
start_date = '\"2017-06-15T10:51:00+0200\"' # str | Search by minimal date (optional)
end_date = '\"2017-06-15T10:51:00+0200\"' # str | Search by maximal date (optional)
provenance = '\"http://www.opensilex.org/demo/2018/pv181515071552\"' # str | Search by provenance uri (optional)
concerned_items = ['\"http://www.opensilex.org/demo/2018/o18000076\"'] # list[str] | Search by concerned items uri (optional)
json_value_filter = '\"{ \\\"SensingDevice\\\" : \\\"http://www.opensilex.org/demo/s001\\\",\\n\\\"Vector\\\" : \\\"http://www.opensilex.org/demo/v001\\\"}\"' # str | Search by json filter (optional)
date_sort_asc = true # bool | Date search result order ('true' for ascending and 'false' for descending) (optional)


try:
    # Retrieve data file descriptions corresponding to the search parameters given.
    api_response = api_instance.get_data_file_descriptions_by_search(rdf_type, page_size=page_size, page=page, start_date=start_date, end_date=end_date, provenance=provenance, concerned_items=concerned_items, json_value_filter=json_value_filter, date_sort_asc=date_sort_asc)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DataApi->get_data_file_descriptions_by_search: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **rdf_type** | **str**| Search by rdf type uri | 
 **page_size** | **int**| Number of elements per page (limited to 150000) | [optional] [default to 20]
 **page** | **int**| Current page number | [optional] [default to 0]
 **start_date** | **str**| Search by minimal date | [optional] 
 **end_date** | **str**| Search by maximal date | [optional] 
 **provenance** | **str**| Search by provenance uri | [optional] 
 **concerned_items** | [**list[str]**](str.md)| Search by concerned items uri | [optional] 
 **json_value_filter** | **str**| Search by json filter | [optional] 
 **date_sort_asc** | **bool**| Date search result order (&#39;true&#39; for ascending and &#39;false&#39; for descending) | [optional] 


### Return type

[**list[FileDescriptionDTO]**](FileDescriptionDTO.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_data_search**
> list[Data] get_data_search(authorization, page_size=page_size, page=page, variable_uri=variable_uri, start_date=start_date, end_date=end_date, object_uri=object_uri, object_label=object_label, provenance_uri=provenance_uri, provenance_label=provenance_label, date_sort_asc=date_sort_asc)

Get data corresponding to the search parameters given.

Retrieve all data corresponding to the search parameters given,<br/>Date parameters could be either a datetime like: 2017-06-15T10:51:00+0200<br/>or simply a date like: 2017-06-15

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.DataApi(pythonClient)
page_size = 20 # int | Number of elements per page (limited to 150000) (optional) (default to 20)
page = 0 # int | Current page number (optional) (default to 0)
variable_uri = '\"http://www.opensilex.org/demo/id/variable/v0000001\"' # str | Search by variable uri (optional)
start_date = '\"2017-06-15T10:51:00+0200\"' # str | Search by minimal date (optional)
end_date = '\"2017-06-15T10:51:00+0200\"' # str | Search by maximal date (optional)
object_uri = '\"http://www.opensilex.org/demo/2018/o18000076\"' # str | Search by object uri (optional)
object_label = '\"Plot01\"' # str | Search by object label (optional)
provenance_uri = '\"http://www.opensilex.org/demo/2018/pv181515071552\"' # str | Search by provenance uri (optional)
provenance_label = '\"PROV2019-LEAF\"' # str | Search by provenance label (optional)
date_sort_asc = true # bool | Date search result order ('true' for ascending and 'false' for descending) (optional)


try:
    # Get data corresponding to the search parameters given.
    api_response = api_instance.get_data_search(page_size=page_size, page=page, variable_uri=variable_uri, start_date=start_date, end_date=end_date, object_uri=object_uri, object_label=object_label, provenance_uri=provenance_uri, provenance_label=provenance_label, date_sort_asc=date_sort_asc)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DataApi->get_data_search: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page_size** | **int**| Number of elements per page (limited to 150000) | [optional] [default to 20]
 **page** | **int**| Current page number | [optional] [default to 0]
 **variable_uri** | **str**| Search by variable uri | [optional] 
 **start_date** | **str**| Search by minimal date | [optional] 
 **end_date** | **str**| Search by maximal date | [optional] 
 **object_uri** | **str**| Search by object uri | [optional] 
 **object_label** | **str**| Search by object label | [optional] 
 **provenance_uri** | **str**| Search by provenance uri | [optional] 
 **provenance_label** | **str**| Search by provenance label | [optional] 
 **date_sort_asc** | **bool**| Date search result order (&#39;true&#39; for ascending and &#39;false&#39; for descending) | [optional] 


### Return type

[**list[Data]**](Data.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post_data**
> ResponseFormPOST post_data(authorization, body=body)

Post data

Register data in the database

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.DataApi(pythonClient)
body = [WeisWSClient.DataPostDTO()] # list[DataPostDTO] | JSON format to insert data (optional)


try:
    # Post data
    api_response = api_instance.post_data(body=body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DataApi->post_data: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**list[DataPostDTO]**](DataPostDTO.md)| JSON format to insert data | [optional] 


### Return type

[**ResponseFormPOST**](ResponseFormPOST.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post_data_file**
> ResponseFormPOST post_data_file(description, file, authorization)

Post data file



### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.DataApi(pythonClient)
description = WeisWSClient.Object() # Object | File description with metadata
file = '/path/to/file.txt' # file | Data file


try:
    # Post data file
    api_response = api_instance.post_data_file(description, file, )
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DataApi->post_data_file: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **description** | [**Object**](.md)| File description with metadata | 
 **file** | **file**| Data file | 


### Return type

[**ResponseFormPOST**](ResponseFormPOST.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: multipart/form-data
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post_data_file_path**
> ResponseFormPOST post_data_file_path(body, authorization)

Post data file



### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.DataApi(pythonClient)
body = [WeisWSClient.FileDescriptionWebPathPostDTO()] # list[FileDescriptionWebPathPostDTO] | Metadata of the file


try:
    # Post data file
    api_response = api_instance.post_data_file_path(body, )
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DataApi->post_data_file_path: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**list[FileDescriptionWebPathPostDTO]**](FileDescriptionWebPathPostDTO.md)| Metadata of the file | 


### Return type

[**ResponseFormPOST**](ResponseFormPOST.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

