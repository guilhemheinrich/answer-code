# ModelProperty

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**rdf_type** | **str** |  | [optional] 
**rdf_type_labels** | **list[str]** |  | [optional] 
**relation** | **str** |  | [optional] 
**relation_labels** | **list[str]** |  | [optional] 
**value** | **str** |  | [optional] 
**value_labels** | **list[str]** |  | [optional] 
**domain** | **str** |  | [optional] 
**labels** | **dict(str, str)** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


