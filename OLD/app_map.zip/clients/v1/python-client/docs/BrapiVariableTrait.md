# BrapiVariableTrait

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**trait_db_id** | **str** |  | [optional] 
**trait_name** | **str** |  | [optional] 
**brapiclass** | **str** |  | [optional] 
**description** | **str** |  | [optional] 
**synonyms** | **list[str]** |  | [optional] 
**main_abbreviation** | **str** |  | [optional] 
**alternative_abbreviations** | **list[str]** |  | [optional] 
**entity** | **str** |  | [optional] 
**attribute** | **str** |  | [optional] 
**status** | **str** |  | [optional] 
**xref** | **str** |  | [optional] 
**ontology_reference** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


