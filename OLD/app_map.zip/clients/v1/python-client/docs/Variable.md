# Variable

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**uri** | **str** |  | [optional] 
**label** | **str** |  | [optional] 
**comment** | **str** |  | [optional] 
**ontologies_references** | [**list[OntologyReference]**](OntologyReference.md) |  | [optional] 
**properties** | [**list[ModelProperty]**](ModelProperty.md) |  | [optional] 
**trait** | [**Trait**](Trait.md) |  | [optional] 
**method** | [**Method**](Method.md) |  | [optional] 
**unit** | [**Unit**](Unit.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


