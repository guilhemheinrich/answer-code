# WeisWSClient.Brapiv1tokenApi

All URIs are relative to *http://www.opensilex.org:8080/weisAPI/rest*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_token**](Brapiv1tokenApi.md#get_token) | **POST** /brapi/v1/token | Login
[**log_out**](Brapiv1tokenApi.md#log_out) | **DELETE** /brapi/v1/token | Log out


# **get_token**
> get_token(body=body)

Login

Returns an access token when the user is known and it issuer too

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.Brapiv1tokenApi(pythonClient)
body = WeisWSClient.TokenDTO() # TokenDTO | JSON object needed to login (optional)


try:
    # Login
    api_instance.get_token(body=body)
except ApiException as e:
    print("Exception when calling Brapiv1tokenApi->get_token: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TokenDTO**](TokenDTO.md)| JSON object needed to login | [optional] 


### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **log_out**
> log_out(body=body)

Log out

Disconnect a logged user

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.Brapiv1tokenApi(pythonClient)
body = WeisWSClient.LogoutDTO() # LogoutDTO | JSON object needed to login (optional)


try:
    # Log out
    api_instance.log_out(body=body)
except ApiException as e:
    print("Exception when calling Brapiv1tokenApi->log_out: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**LogoutDTO**](LogoutDTO.md)| JSON object needed to login | [optional] 


### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

