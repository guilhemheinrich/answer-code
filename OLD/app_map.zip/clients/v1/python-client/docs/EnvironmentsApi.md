# WeisWSClient.EnvironmentsApi

All URIs are relative to *http://www.opensilex.org:8080/weisAPI/rest*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_environment_measures**](EnvironmentsApi.md#get_environment_measures) | **GET** /environments | Get all environment measures corresponding to the search params given
[**post_environment_measures**](EnvironmentsApi.md#post_environment_measures) | **POST** /environments | Post environment(s) measures


# **get_environment_measures**
> list[EnvironmentMeasureDTO] get_environment_measures(variable, authorization, page_size=page_size, page=page, start_date=start_date, end_date=end_date, sensor=sensor, date_sort_asc=date_sort_asc)

Get all environment measures corresponding to the search params given

Retrieve all environment measures authorized for the user corresponding to the searched params given

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.EnvironmentsApi(pythonClient)
variable = '\"http://www.opensilex.org/demo/id/variable/v0000001\"' # str | Search by variable uri
page_size = 20 # int | Number of elements per page (limited to 150000) (optional) (default to 20)
page = 0 # int | Current page number (optional) (default to 0)
start_date = '\"2017-06-15T10:51:00+0200\"' # str | Search by minimal date (optional)
end_date = '\"2017-06-15T10:51:00+0200\"' # str | Search by maximal date (optional)
sensor = '\"http://www.opensilex.org/demo/2018/s18001\"' # str | Search by sensor uri (optional)
date_sort_asc = true # bool | Date search result order ('true' for ascending and 'false' for descending) (optional)


try:
    # Get all environment measures corresponding to the search params given
    api_response = api_instance.get_environment_measures(variable, page_size=page_size, page=page, start_date=start_date, end_date=end_date, sensor=sensor, date_sort_asc=date_sort_asc)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling EnvironmentsApi->get_environment_measures: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **variable** | **str**| Search by variable uri | 
 **page_size** | **int**| Number of elements per page (limited to 150000) | [optional] [default to 20]
 **page** | **int**| Current page number | [optional] [default to 0]
 **start_date** | **str**| Search by minimal date | [optional] 
 **end_date** | **str**| Search by maximal date | [optional] 
 **sensor** | **str**| Search by sensor uri | [optional] 
 **date_sort_asc** | **bool**| Date search result order (&#39;true&#39; for ascending and &#39;false&#39; for descending) | [optional] 


### Return type

[**list[EnvironmentMeasureDTO]**](EnvironmentMeasureDTO.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post_environment_measures**
> ResponseFormPOST post_environment_measures(authorization, body=body)

Post environment(s) measures

Register environment(s) measures in the database<br/> The 'value' parameter could be a string representing any java BigDecimal<br/> By example it could be: -2, 3.14, 1.23E+3, -1.23e-12, etc...<br/> @see https://docs.oracle.com/javase/7/docs/api/java/math/BigDecimal.html#BigDecimal(java.lang.String)

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.EnvironmentsApi(pythonClient)
body = [WeisWSClient.EnvironmentMeasurePostDTO()] # list[EnvironmentMeasurePostDTO] | JSON format to insert environment (optional)


try:
    # Post environment(s) measures
    api_response = api_instance.post_environment_measures(body=body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling EnvironmentsApi->post_environment_measures: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**list[EnvironmentMeasurePostDTO]**](EnvironmentMeasurePostDTO.md)| JSON format to insert environment | [optional] 


### Return type

[**ResponseFormPOST**](ResponseFormPOST.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

