# WeisWSClient.GroupApi

All URIs are relative to *http://www.opensilex.org:8080/weisAPI/rest*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_group_by_search**](GroupApi.md#get_group_by_search) | **GET** /groups | Get all groups corresponding to the searched params given
[**get_group_details**](GroupApi.md#get_group_details) | **GET** /groups/{groupURI} | Get a group
[**post_group**](GroupApi.md#post_group) | **POST** /groups | Post a group
[**put_group**](GroupApi.md#put_group) | **PUT** /groups | Update groups


# **get_group_by_search**
> list[Group] get_group_by_search(authorization, page_size=page_size, page=page, uri=uri, name=name, level=level)

Get all groups corresponding to the searched params given

Retrieve all groups authorized for the user corresponding to the searched params given

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.GroupApi(pythonClient)
page_size = 20 # int | Number of elements per page (limited to 150000) (optional) (default to 20)
page = 0 # int | Current page number (optional) (default to 0)
uri = '\"http://phenome-fppn.fr/demo/INRA-MISTEA-GAMMA\"' # str | Search by uri (optional)
name = '\"INRA-MISTEA-GAMMA\"' # str | Search by name (optional)
level = '\"Owner\"' # str | Search by level (optional)


try:
    # Get all groups corresponding to the searched params given
    api_response = api_instance.get_group_by_search(page_size=page_size, page=page, uri=uri, name=name, level=level)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling GroupApi->get_group_by_search: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page_size** | **int**| Number of elements per page (limited to 150000) | [optional] [default to 20]
 **page** | **int**| Current page number | [optional] [default to 0]
 **uri** | **str**| Search by uri | [optional] 
 **name** | **str**| Search by name | [optional] 
 **level** | **str**| Search by level | [optional] 


### Return type

[**list[Group]**](Group.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_group_details**
> list[Group] get_group_details(group_uri, authorization, page_size=page_size, page=page)

Get a group

Retrieve a group. Need group name.

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.GroupApi(pythonClient)
group_uri = '\"http://phenome-fppn.fr/demo/INRA-MISTEA-GAMMA\"' # str | A group uri
page_size = 20 # int | Number of elements per page (limited to 150000) (optional) (default to 20)
page = 0 # int | Current page number (optional) (default to 0)


try:
    # Get a group
    api_response = api_instance.get_group_details(group_uri, page_size=page_size, page=page)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling GroupApi->get_group_details: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **group_uri** | **str**| A group uri | 
 **page_size** | **int**| Number of elements per page (limited to 150000) | [optional] [default to 20]
 **page** | **int**| Current page number | [optional] [default to 0]


### Return type

[**list[Group]**](Group.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post_group**
> ResponseFormPOST post_group(body, authorization)

Post a group

Register a new group in the database

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.GroupApi(pythonClient)
body = [WeisWSClient.GroupPostDTO()] # list[GroupPostDTO] | JSON format of group data


try:
    # Post a group
    api_response = api_instance.post_group(body, )
    pprint(api_response)
except ApiException as e:
    print("Exception when calling GroupApi->post_group: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**list[GroupPostDTO]**](GroupPostDTO.md)| JSON format of group data | 


### Return type

[**ResponseFormPOST**](ResponseFormPOST.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **put_group**
> ResponseFormPOST put_group(body, authorization)

Update groups



### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.GroupApi(pythonClient)
body = [WeisWSClient.GroupDTO()] # list[GroupDTO] | JSON format of group data


try:
    # Update groups
    api_response = api_instance.put_group(body, )
    pprint(api_response)
except ApiException as e:
    print("Exception when calling GroupApi->put_group: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**list[GroupDTO]**](GroupDTO.md)| JSON format of group data | 


### Return type

[**ResponseFormPOST**](ResponseFormPOST.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

