# ImageMetadata

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**uri** | **str** |  | [optional] 
**rdf_type** | **str** |  | [optional] 
**concerned_items** | [**list[ConcernedItem]**](ConcernedItem.md) |  | [optional] 
**configuration** | [**ShootingConfiguration**](ShootingConfiguration.md) |  | [optional] 
**file_informations** | [**FileInformations**](FileInformations.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


