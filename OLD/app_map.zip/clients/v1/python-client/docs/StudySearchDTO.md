# StudySearchDTO

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**common_crop_name** | **str** |  | [optional] 
**season_db_id** | **str** |  | [optional] 
**study_db_ids** | **list[str]** |  | [optional] 
**study_names** | **list[str]** |  | [optional] 
**sort_by** | **str** |  | [optional] 
**sort_order** | **str** |  | [optional] 
**page** | **int** |  | [optional] 
**page_size** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


