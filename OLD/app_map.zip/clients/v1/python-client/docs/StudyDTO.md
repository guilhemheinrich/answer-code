# StudyDTO

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**active** | **str** |  | [optional] 
**additional_info** | [**AdditionalInfo**](AdditionalInfo.md) |  | [optional] 
**common_crop_name** | **str** |  | [optional] 
**documentation_url** | **str** |  | [optional] 
**end_date** | **str** |  | [optional] 
**location_db_id** | **str** |  | [optional] 
**location_name** | **str** |  | [optional] 
**name** | **str** |  | [optional] 
**program_db_id** | **str** |  | [optional] 
**program_name** | **str** |  | [optional] 
**seasons** | **list[object]** |  | [optional] 
**start_date** | **str** |  | [optional] 
**study_db_id** | **str** |  | [optional] 
**study_name** | **str** |  | [optional] 
**study_type** | **str** |  | [optional] 
**study_type_db_id** | **str** |  | [optional] 
**study_type_name** | **str** |  | [optional] 
**trial_db_id** | **str** |  | [optional] 
**trial_name** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


