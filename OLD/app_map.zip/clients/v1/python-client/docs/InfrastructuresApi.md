# WeisWSClient.InfrastructuresApi

All URIs are relative to *http://www.opensilex.org:8080/weisAPI/rest*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_infrastructure_details**](InfrastructuresApi.md#get_infrastructure_details) | **GET** /infrastructures/{uri} | Get all infrastructure&#39;s details corresponding to the search uri
[**get_infrastructures_by_search**](InfrastructuresApi.md#get_infrastructures_by_search) | **GET** /infrastructures | Get all infrastructures corresponding to the search params given


# **get_infrastructure_details**
> list[RdfResourceDefinitionDTO] get_infrastructure_details(uri, authorization, language=language, page_size=page_size, page=page)

Get all infrastructure's details corresponding to the search uri

Retrieve all infrastructure's details authorized for the user corresponding to the searched uri

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.InfrastructuresApi(pythonClient)
uri = '\"http://www.opensilex.org/demo\"' # str | An infrastructure URI (Unique Resource Identifier)
language = '\"en\"' # str | Language (optional)
page_size = 20 # int | Number of elements per page (limited to 150000) (optional) (default to 20)
page = 0 # int | Current page number (optional) (default to 0)


try:
    # Get all infrastructure's details corresponding to the search uri
    api_response = api_instance.get_infrastructure_details(uri, language=language, page_size=page_size, page=page)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling InfrastructuresApi->get_infrastructure_details: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **uri** | **str**| An infrastructure URI (Unique Resource Identifier) | 
 **language** | **str**| Language | [optional] 
 **page_size** | **int**| Number of elements per page (limited to 150000) | [optional] [default to 20]
 **page** | **int**| Current page number | [optional] [default to 0]


### Return type

[**list[RdfResourceDefinitionDTO]**](RdfResourceDefinitionDTO.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_infrastructures_by_search**
> list[Infrastructure] get_infrastructures_by_search(authorization, page_size=page_size, page=page, uri=uri, rdf_type=rdf_type, label=label, language=language)

Get all infrastructures corresponding to the search params given

Retrieve all infrastructures authorized for the user corresponding to the searched params given

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.InfrastructuresApi(pythonClient)
page_size = 20 # int | Number of elements per page (limited to 150000) (optional) (default to 20)
page = 0 # int | Current page number (optional) (default to 0)
uri = '\"http://www.opensilex.org/demo\"' # str | Search by uri (optional)
rdf_type = '\"http://www.opensilex.org/vocabulary/oeso#Infrastructure\"' # str | Search by type uri (optional)
label = '\"EMPHASIS\"' # str | Search by label (optional)
language = '\"en\"' # str | Language (optional)


try:
    # Get all infrastructures corresponding to the search params given
    api_response = api_instance.get_infrastructures_by_search(page_size=page_size, page=page, uri=uri, rdf_type=rdf_type, label=label, language=language)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling InfrastructuresApi->get_infrastructures_by_search: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page_size** | **int**| Number of elements per page (limited to 150000) | [optional] [default to 20]
 **page** | **int**| Current page number | [optional] [default to 0]
 **uri** | **str**| Search by uri | [optional] 
 **rdf_type** | **str**| Search by type uri | [optional] 
 **label** | **str**| Search by label | [optional] 
 **language** | **str**| Language | [optional] 


### Return type

[**list[Infrastructure]**](Infrastructure.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

