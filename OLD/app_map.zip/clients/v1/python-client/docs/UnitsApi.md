# WeisWSClient.UnitsApi

All URIs are relative to *http://www.opensilex.org:8080/weisAPI/rest*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_unit_details**](UnitsApi.md#get_unit_details) | **GET** /units/{unit} | Get a unit
[**get_units_by_search**](UnitsApi.md#get_units_by_search) | **GET** /units | Get all units corresponding to the searched params given
[**post_unit**](UnitsApi.md#post_unit) | **POST** /units | Post unit(s)
[**put_unit**](UnitsApi.md#put_unit) | **PUT** /units | Update unit


# **get_unit_details**
> list[Unit] get_unit_details(unit, authorization, page_size=page_size, page=page)

Get a unit

Retrieve a unit. Need URL encoded unit URI (Unique resource identifier).

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.UnitsApi(pythonClient)
unit = '\"http://www.opensilex.org/demo/id/units/u001\"' # str | A unit URI (Unique Resource Identifier)
page_size = 20 # int | Number of elements per page (limited to 150000) (optional) (default to 20)
page = 0 # int | Current page number (optional) (default to 0)


try:
    # Get a unit
    api_response = api_instance.get_unit_details(unit, page_size=page_size, page=page)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling UnitsApi->get_unit_details: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **unit** | **str**| A unit URI (Unique Resource Identifier) | 
 **page_size** | **int**| Number of elements per page (limited to 150000) | [optional] [default to 20]
 **page** | **int**| Current page number | [optional] [default to 0]


### Return type

[**list[Unit]**](Unit.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_units_by_search**
> list[Unit] get_units_by_search(authorization, page_size=page_size, page=page, uri=uri, label=label)

Get all units corresponding to the searched params given

Retrieve all units authorized for the user corresponding to the user corresponding to the searched params given

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.UnitsApi(pythonClient)
page_size = 20 # int | Number of elements per page (limited to 150000) (optional) (default to 20)
page = 0 # int | Current page number (optional) (default to 0)
uri = '\"http://www.opensilex.org/demo/id/units/u001\"' # str | Search by URI (optional)
label = '\"cm\"' # str | Search by label (optional)


try:
    # Get all units corresponding to the searched params given
    api_response = api_instance.get_units_by_search(page_size=page_size, page=page, uri=uri, label=label)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling UnitsApi->get_units_by_search: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page_size** | **int**| Number of elements per page (limited to 150000) | [optional] [default to 20]
 **page** | **int**| Current page number | [optional] [default to 0]
 **uri** | **str**| Search by URI | [optional] 
 **label** | **str**| Search by label | [optional] 


### Return type

[**list[Unit]**](Unit.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post_unit**
> ResponseFormPOST post_unit(body, authorization)

Post unit(s)

Register new unit(s) in the data base

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.UnitsApi(pythonClient)
body = [WeisWSClient.UnitDTO()] # list[UnitDTO] | JSON format of unit


try:
    # Post unit(s)
    api_response = api_instance.post_unit(body, )
    pprint(api_response)
except ApiException as e:
    print("Exception when calling UnitsApi->post_unit: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**list[UnitDTO]**](UnitDTO.md)| JSON format of unit | 


### Return type

[**ResponseFormPOST**](ResponseFormPOST.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **put_unit**
> ResponseFormPOST put_unit(authorization, body=body)

Update unit



### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.UnitsApi(pythonClient)
body = [WeisWSClient.UnitDTO()] # list[UnitDTO] | JSON format of unit (optional)


try:
    # Update unit
    api_response = api_instance.put_unit(body=body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling UnitsApi->put_unit: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**list[UnitDTO]**](UnitDTO.md)| JSON format of unit | [optional] 


### Return type

[**ResponseFormPOST**](ResponseFormPOST.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

