# WeisWSClient.SensorsApi

All URIs are relative to *http://www.opensilex.org:8080/weisAPI/rest*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_sensor_details**](SensorsApi.md#get_sensor_details) | **GET** /sensors/{uri} | Get a sensor
[**get_sensor_profile**](SensorsApi.md#get_sensor_profile) | **GET** /sensors/profiles/{uri} | Get a sensor profile
[**get_sensors_by_search**](SensorsApi.md#get_sensors_by_search) | **GET** /sensors | Get all sensors corresponding to the search params given
[**post5**](SensorsApi.md#post5) | **POST** /sensors | Post a sensor
[**post_profiles**](SensorsApi.md#post_profiles) | **POST** /sensors/profiles | Post sensor(s) profile(s)
[**put6**](SensorsApi.md#put6) | **PUT** /sensors | Update sensors
[**put_measured_variables1**](SensorsApi.md#put_measured_variables1) | **PUT** /sensors/{uri}/variables | Update the measured variables of a sensor


# **get_sensor_details**
> list[SensorDetailDTO] get_sensor_details(uri, authorization, page_size=page_size, page=page)

Get a sensor

Retrieve a sensor. Need URL encoded sensor URI

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.SensorsApi(pythonClient)
uri = '\"http://www.opensilex.org/demo/2018/s18001\"' # str | a sensor URI (Unique Resource Identifier)
page_size = 20 # int | Number of elements per page (limited to 150000) (optional) (default to 20)
page = 0 # int | Current page number (optional) (default to 0)


try:
    # Get a sensor
    api_response = api_instance.get_sensor_details(uri, page_size=page_size, page=page)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SensorsApi->get_sensor_details: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **uri** | **str**| a sensor URI (Unique Resource Identifier) | 
 **page_size** | **int**| Number of elements per page (limited to 150000) | [optional] [default to 20]
 **page** | **int**| Current page number | [optional] [default to 0]


### Return type

[**list[SensorDetailDTO]**](SensorDetailDTO.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_sensor_profile**
> list[Sensor] get_sensor_profile(uri, authorization, page_size=page_size, page=page)

Get a sensor profile

Retrieve a sensor profile. Need URL encoded sensor URI

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.SensorsApi(pythonClient)
uri = '\"http://www.opensilex.org/demo/2018/s18001\"' # str | a sensor URI (Unique Resource Identifier)
page_size = 20 # int | Number of elements per page (limited to 150000) (optional) (default to 20)
page = 0 # int | Current page number (optional) (default to 0)


try:
    # Get a sensor profile
    api_response = api_instance.get_sensor_profile(uri, page_size=page_size, page=page)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SensorsApi->get_sensor_profile: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **uri** | **str**| a sensor URI (Unique Resource Identifier) | 
 **page_size** | **int**| Number of elements per page (limited to 150000) | [optional] [default to 20]
 **page** | **int**| Current page number | [optional] [default to 0]


### Return type

[**list[Sensor]**](Sensor.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_sensors_by_search**
> list[SensorDetailDTO] get_sensors_by_search(authorization, page_size=page_size, page=page, uri=uri, rdf_type=rdf_type, label=label, brand=brand, serial_number=serial_number, model=model, in_service_date=in_service_date, date_of_purchase=date_of_purchase, date_of_last_calibration=date_of_last_calibration, person_in_charge=person_in_charge)

Get all sensors corresponding to the search params given

Retrieve all sensors authorized for the user corresponding to the searched params given

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.SensorsApi(pythonClient)
page_size = 20 # int | Number of elements per page (limited to 150000) (optional) (default to 20)
page = 0 # int | Current page number (optional) (default to 0)
uri = '\"http://www.opensilex.org/demo/2018/s18001\"' # str | Search by uri (optional)
rdf_type = '\"http://www.opensilex.org/vocabulary/oeso#Sensor\"' # str | Search by type uri (optional)
label = '\"par03_p\"' # str | Search by label (optional)
brand = '\"Skye Instruments\"' # str | Search by brand (optional)
serial_number = '\"A1E345F32\"' # str | Search by serial number (optional)
model = '\"m001\"' # str | Search by model (optional)
in_service_date = '\"2017-06-15\"' # str | Search by service date (optional)
date_of_purchase = '\"2017-06-15\"' # str | Search by date of purchase (optional)
date_of_last_calibration = '\"2017-06-15\"' # str | Search by date of last calibration (optional)
person_in_charge = '\"admin@opensilex.org\"' # str | Search by person in charge (optional)


try:
    # Get all sensors corresponding to the search params given
    api_response = api_instance.get_sensors_by_search(page_size=page_size, page=page, uri=uri, rdf_type=rdf_type, label=label, brand=brand, serial_number=serial_number, model=model, in_service_date=in_service_date, date_of_purchase=date_of_purchase, date_of_last_calibration=date_of_last_calibration, person_in_charge=person_in_charge)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SensorsApi->get_sensors_by_search: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page_size** | **int**| Number of elements per page (limited to 150000) | [optional] [default to 20]
 **page** | **int**| Current page number | [optional] [default to 0]
 **uri** | **str**| Search by uri | [optional] 
 **rdf_type** | **str**| Search by type uri | [optional] 
 **label** | **str**| Search by label | [optional] 
 **brand** | **str**| Search by brand | [optional] 
 **serial_number** | **str**| Search by serial number | [optional] 
 **model** | **str**| Search by model | [optional] 
 **in_service_date** | **str**| Search by service date | [optional] 
 **date_of_purchase** | **str**| Search by date of purchase | [optional] 
 **date_of_last_calibration** | **str**| Search by date of last calibration | [optional] 
 **person_in_charge** | **str**| Search by person in charge | [optional] 


### Return type

[**list[SensorDetailDTO]**](SensorDetailDTO.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post5**
> ResponseFormPOST post5(authorization, body=body)

Post a sensor

Register a new sensor in the database

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.SensorsApi(pythonClient)
body = [WeisWSClient.SensorPostDTO()] # list[SensorPostDTO] | JSON format of sensor data (optional)


try:
    # Post a sensor
    api_response = api_instance.post5(body=body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SensorsApi->post5: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**list[SensorPostDTO]**](SensorPostDTO.md)| JSON format of sensor data | [optional] 


### Return type

[**ResponseFormPOST**](ResponseFormPOST.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post_profiles**
> ResponseFormPOST post_profiles(authorization, body=body)

Post sensor(s) profile(s)

Register sensor(s) profile(s) in the database

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.SensorsApi(pythonClient)
body = [WeisWSClient.SensorProfileDTO()] # list[SensorProfileDTO] | JSON format of sensor profile data (optional)


try:
    # Post sensor(s) profile(s)
    api_response = api_instance.post_profiles(body=body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SensorsApi->post_profiles: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**list[SensorProfileDTO]**](SensorProfileDTO.md)| JSON format of sensor profile data | [optional] 


### Return type

[**ResponseFormPOST**](ResponseFormPOST.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **put6**
> ResponseFormPOST put6(authorization, body=body)

Update sensors



### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.SensorsApi(pythonClient)
body = [WeisWSClient.SensorDTO()] # list[SensorDTO] | JSON format of sensor data (optional)


try:
    # Update sensors
    api_response = api_instance.put6(body=body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SensorsApi->put6: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**list[SensorDTO]**](SensorDTO.md)| JSON format of sensor data | [optional] 


### Return type

[**ResponseFormPOST**](ResponseFormPOST.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **put_measured_variables1**
> ResponseFormPOST put_measured_variables1(uri, authorization, body=body)

Update the measured variables of a sensor



### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.SensorsApi(pythonClient)
uri = '\"http://www.opensilex.org/demo/2018/s18001\"' # str | a sensor URI (Unique Resource Identifier)
body = [WeisWSClient.list[str]()] # list[str] | List of variables uris (optional)


try:
    # Update the measured variables of a sensor
    api_response = api_instance.put_measured_variables1(uri, body=body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SensorsApi->put_measured_variables1: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **uri** | **str**| a sensor URI (Unique Resource Identifier) | 
 **body** | **list[str]**| List of variables uris | [optional] 


### Return type

[**ResponseFormPOST**](ResponseFormPOST.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

