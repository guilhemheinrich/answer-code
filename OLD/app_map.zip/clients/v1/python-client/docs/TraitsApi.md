# WeisWSClient.TraitsApi

All URIs are relative to *http://www.opensilex.org:8080/weisAPI/rest*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_trait_details**](TraitsApi.md#get_trait_details) | **GET** /traits/{trait} | Get a trait
[**get_traits_by_search**](TraitsApi.md#get_traits_by_search) | **GET** /traits | Get all Traits corresponding to the searched params given
[**post_trait**](TraitsApi.md#post_trait) | **POST** /traits | Post trait(s)
[**put_trait**](TraitsApi.md#put_trait) | **PUT** /traits | Update trait


# **get_trait_details**
> list[Trait] get_trait_details(trait, authorization, page_size=page_size, page=page)

Get a trait

Retrieve a trait. Need URL encoded trait URI (Unique resource identifier).

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.TraitsApi(pythonClient)
trait = '\"http://www.opensilex.org/demo/id/traits/t001\"' # str | A trait URI (Unique Resource Identifier)
page_size = 20 # int | Number of elements per page (limited to 150000) (optional) (default to 20)
page = 0 # int | Current page number (optional) (default to 0)


try:
    # Get a trait
    api_response = api_instance.get_trait_details(trait, page_size=page_size, page=page)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling TraitsApi->get_trait_details: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **trait** | **str**| A trait URI (Unique Resource Identifier) | 
 **page_size** | **int**| Number of elements per page (limited to 150000) | [optional] [default to 20]
 **page** | **int**| Current page number | [optional] [default to 0]


### Return type

[**list[Trait]**](Trait.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_traits_by_search**
> list[Trait] get_traits_by_search(authorization, page_size=page_size, page=page, uri=uri, label=label)

Get all Traits corresponding to the searched params given

Retrieve all traits authorized for the user corresponding to the user corresponding to the searched params given

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.TraitsApi(pythonClient)
page_size = 20 # int | Number of elements per page (limited to 150000) (optional) (default to 20)
page = 0 # int | Current page number (optional) (default to 0)
uri = '\"http://www.opensilex.org/demo/id/traits/t001\"' # str | Search by URI (optional)
label = '\"Height\"' # str | Search by label (optional)


try:
    # Get all Traits corresponding to the searched params given
    api_response = api_instance.get_traits_by_search(page_size=page_size, page=page, uri=uri, label=label)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling TraitsApi->get_traits_by_search: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page_size** | **int**| Number of elements per page (limited to 150000) | [optional] [default to 20]
 **page** | **int**| Current page number | [optional] [default to 0]
 **uri** | **str**| Search by URI | [optional] 
 **label** | **str**| Search by label | [optional] 


### Return type

[**list[Trait]**](Trait.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post_trait**
> ResponseFormPOST post_trait(authorization, body=body)

Post trait(s)

Register new trait(s) in the data base

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.TraitsApi(pythonClient)
body = [WeisWSClient.TraitDTO()] # list[TraitDTO] | JSON format of trait (optional)


try:
    # Post trait(s)
    api_response = api_instance.post_trait(body=body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling TraitsApi->post_trait: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**list[TraitDTO]**](TraitDTO.md)| JSON format of trait | [optional] 


### Return type

[**ResponseFormPOST**](ResponseFormPOST.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **put_trait**
> ResponseFormPOST put_trait(authorization, body=body)

Update trait



### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.TraitsApi(pythonClient)
body = [WeisWSClient.TraitDTO()] # list[TraitDTO] | JSON format of trait (optional)


try:
    # Update trait
    api_response = api_instance.put_trait(body=body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling TraitsApi->put_trait: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**list[TraitDTO]**](TraitDTO.md)| JSON format of trait | [optional] 


### Return type

[**ResponseFormPOST**](ResponseFormPOST.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

