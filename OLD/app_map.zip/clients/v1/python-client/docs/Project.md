# Project

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**uri** | **str** |  | [optional] 
**name** | **str** |  | [optional] 
**shortname** | **str** |  | [optional] 
**related_projects** | [**list[Project]**](Project.md) |  | [optional] 
**financial_funding** | [**FinancialFunding**](FinancialFunding.md) |  | [optional] 
**financial_reference** | **str** |  | [optional] 
**description** | **str** |  | [optional] 
**start_date** | **str** |  | [optional] 
**end_date** | **str** |  | [optional] 
**keywords** | **list[str]** |  | [optional] 
**home_page** | **str** |  | [optional] 
**administrative_contacts** | [**list[Contact]**](Contact.md) |  | [optional] 
**coordinators** | [**list[Contact]**](Contact.md) |  | [optional] 
**scientific_contacts** | [**list[Contact]**](Contact.md) |  | [optional] 
**objective** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


