# WeisWSClient.ExperimentsApi

All URIs are relative to *http://www.opensilex.org:8080/weisAPI/rest*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_experiment_detail**](ExperimentsApi.md#get_experiment_detail) | **GET** /experiments/{experiment} | Get an experiment
[**get_experiments_by_search**](ExperimentsApi.md#get_experiments_by_search) | **GET** /experiments | Get all experiments corresponding to the searched params given
[**post_experiment**](ExperimentsApi.md#post_experiment) | **POST** /experiments | Post a experiment
[**put_experiment**](ExperimentsApi.md#put_experiment) | **PUT** /experiments | Update experiment
[**put_sensors**](ExperimentsApi.md#put_sensors) | **PUT** /experiments/{uri}/sensors | Update the sensors which participates in an experiment
[**put_variables**](ExperimentsApi.md#put_variables) | **PUT** /experiments/{uri}/variables | Update the observed variables of an experiment


# **get_experiment_detail**
> list[Experiment] get_experiment_detail(experiment, authorization, page_size=page_size, page=page)

Get an experiment

Retrieve an experiment. Need URL encoded experiment URI (Unique resource identifier).

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.ExperimentsApi(pythonClient)
experiment = '\"http://www.opensilex.org/demo/DMO2012-1\"' # str | An experiment URI (Unique Resource Identifier)
page_size = 20 # int | Number of elements per page (limited to 150000) (optional) (default to 20)
page = 0 # int | Current page number (optional) (default to 0)


try:
    # Get an experiment
    api_response = api_instance.get_experiment_detail(experiment, page_size=page_size, page=page)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ExperimentsApi->get_experiment_detail: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **experiment** | **str**| An experiment URI (Unique Resource Identifier) | 
 **page_size** | **int**| Number of elements per page (limited to 150000) | [optional] [default to 20]
 **page** | **int**| Current page number | [optional] [default to 0]


### Return type

[**list[Experiment]**](Experiment.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_experiments_by_search**
> list[Experiment] get_experiments_by_search(authorization, page_size=page_size, page=page, uri=uri, project_uri=project_uri, start_date=start_date, end_date=end_date, field=field, campaign=campaign, place=place, alias=alias, keywords=keywords)

Get all experiments corresponding to the searched params given

Retrieve all experiments authorized for the user corresponding to the searched params given

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.ExperimentsApi(pythonClient)
page_size = 20 # int | Number of elements per page (limited to 150000) (optional) (default to 20)
page = 0 # int | Current page number (optional) (default to 0)
uri = '\"http://www.opensilex.org/demo/DMO2012-1\"' # str | Search by uri (optional)
project_uri = '\"http://www.opensilex.org/demo/projectTest\"' # str | Search by project uri (optional)
start_date = '\"2017-06-15 10:51:00+0200\"' # str | Search by start date (optional)
end_date = '\"2017-06-15 10:51:00+0200\"' # str | Search by end date (optional)
field = '\"field\"' # str | Search by field (optional)
campaign = '\"2012\"' # str | Search by campaign (optional)
place = '\"place\"' # str | Search by place (optional)
alias = '\"alias\"' # str | Search by alias (optional)
keywords = '\"keywords\"' # str | Search by keywords (optional)


try:
    # Get all experiments corresponding to the searched params given
    api_response = api_instance.get_experiments_by_search(page_size=page_size, page=page, uri=uri, project_uri=project_uri, start_date=start_date, end_date=end_date, field=field, campaign=campaign, place=place, alias=alias, keywords=keywords)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ExperimentsApi->get_experiments_by_search: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page_size** | **int**| Number of elements per page (limited to 150000) | [optional] [default to 20]
 **page** | **int**| Current page number | [optional] [default to 0]
 **uri** | **str**| Search by uri | [optional] 
 **project_uri** | **str**| Search by project uri | [optional] 
 **start_date** | **str**| Search by start date | [optional] 
 **end_date** | **str**| Search by end date | [optional] 
 **field** | **str**| Search by field | [optional] 
 **campaign** | **str**| Search by campaign | [optional] 
 **place** | **str**| Search by place | [optional] 
 **alias** | **str**| Search by alias | [optional] 
 **keywords** | **str**| Search by keywords | [optional] 


### Return type

[**list[Experiment]**](Experiment.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post_experiment**
> ResponseFormPOST post_experiment(authorization, body=body)

Post a experiment

Register a new experiment in the database

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.ExperimentsApi(pythonClient)
body = [WeisWSClient.ExperimentPostDTO()] # list[ExperimentPostDTO] | JSON format of experiment data (optional)


try:
    # Post a experiment
    api_response = api_instance.post_experiment(body=body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ExperimentsApi->post_experiment: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**list[ExperimentPostDTO]**](ExperimentPostDTO.md)| JSON format of experiment data | [optional] 


### Return type

[**ResponseFormPOST**](ResponseFormPOST.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **put_experiment**
> ResponseFormPOST put_experiment(authorization, body=body)

Update experiment



### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.ExperimentsApi(pythonClient)
body = [WeisWSClient.ExperimentDTO()] # list[ExperimentDTO] | JSON format of experiment data (optional)


try:
    # Update experiment
    api_response = api_instance.put_experiment(body=body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ExperimentsApi->put_experiment: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**list[ExperimentDTO]**](ExperimentDTO.md)| JSON format of experiment data | [optional] 


### Return type

[**ResponseFormPOST**](ResponseFormPOST.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **put_sensors**
> ResponseFormPOST put_sensors(uri, authorization, body=body)

Update the sensors which participates in an experiment



### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.ExperimentsApi(pythonClient)
uri = '\"http://www.opensilex.org/demo/DMO2012-1\"' # str | An experiment URI (Unique Resource Identifier)
body = [WeisWSClient.list[str]()] # list[str] | List of sensors uris. (optional)


try:
    # Update the sensors which participates in an experiment
    api_response = api_instance.put_sensors(uri, body=body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ExperimentsApi->put_sensors: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **uri** | **str**| An experiment URI (Unique Resource Identifier) | 
 **body** | **list[str]**| List of sensors uris. | [optional] 


### Return type

[**ResponseFormPOST**](ResponseFormPOST.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **put_variables**
> ResponseFormPOST put_variables(uri, authorization, body=body)

Update the observed variables of an experiment



### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.ExperimentsApi(pythonClient)
uri = '\"http://www.opensilex.org/demo/DMO2012-1\"' # str | An experiment URI (Unique Resource Identifier)
body = [WeisWSClient.list[str]()] # list[str] | List of variables uris (optional)


try:
    # Update the observed variables of an experiment
    api_response = api_instance.put_variables(uri, body=body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ExperimentsApi->put_variables: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **uri** | **str**| An experiment URI (Unique Resource Identifier) | 
 **body** | **list[str]**| List of variables uris | [optional] 


### Return type

[**ResponseFormPOST**](ResponseFormPOST.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

