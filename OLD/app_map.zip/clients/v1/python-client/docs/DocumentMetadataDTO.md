# DocumentMetadataDTO

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**uri** | **str** |  | [optional] 
**document_type** | **str** |  | [optional] 
**checksum** | **str** |  | [optional] 
**creator** | **str** |  | [optional] 
**language** | **str** |  | [optional] 
**title** | **str** |  | [optional] 
**creation_date** | **str** |  | [optional] 
**extension** | **str** |  | [optional] 
**comment** | **str** |  | [optional] 
**concerned_items** | [**list[ConcernedItemDTO]**](ConcernedItemDTO.md) |  | [optional] 
**status** | **str** |  | [optional] 
**server_file_path** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


