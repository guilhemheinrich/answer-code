# EventGetDTO

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**uri** | **str** |  | [optional] 
**rdf_type** | **str** |  | [optional] 
**concerned_items** | [**list[ConcernedItemWithLabelsDTO]**](ConcernedItemWithLabelsDTO.md) |  | [optional] 
**_date** | **str** |  | [optional] 
**properties** | [**list[PropertyDTO]**](PropertyDTO.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


