# BrapiScale

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**scale_dbid** | **str** |  | [optional] 
**scale_name** | **str** |  | [optional] 
**data_type** | **str** |  | [optional] 
**decimal_places** | **str** |  | [optional] 
**ontology_reference** | **str** |  | [optional] 
**xref** | **str** |  | [optional] 
**valid_values** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


