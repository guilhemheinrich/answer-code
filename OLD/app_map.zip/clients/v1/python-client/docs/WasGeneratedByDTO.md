# WasGeneratedByDTO

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**was_generated_by_document** | **str** |  | [optional] 
**was_generated_by_description** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


