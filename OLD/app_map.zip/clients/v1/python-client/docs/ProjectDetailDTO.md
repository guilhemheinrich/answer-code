# ProjectDetailDTO

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**uri** | **str** |  | [optional] 
**name** | **str** |  | [optional] 
**shortname** | **str** |  | [optional] 
**related_projects** | [**list[RdfResourceDTO]**](RdfResourceDTO.md) |  | [optional] 
**financial_funding** | [**RdfResourceDTO**](RdfResourceDTO.md) |  | [optional] 
**financial_reference** | **str** |  | [optional] 
**description** | **str** |  | [optional] 
**start_date** | **str** |  | [optional] 
**end_date** | **str** |  | [optional] 
**keywords** | **list[str]** |  | [optional] 
**home_page** | **str** |  | [optional] 
**administrative_contacts** | [**list[ContactDTO]**](ContactDTO.md) |  | [optional] 
**coordinators** | [**list[ContactDTO]**](ContactDTO.md) |  | [optional] 
**scientific_contacts** | [**list[ContactDTO]**](ContactDTO.md) |  | [optional] 
**objective** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


