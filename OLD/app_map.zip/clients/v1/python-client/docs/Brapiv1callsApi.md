# WeisWSClient.Brapiv1callsApi

All URIs are relative to *http://www.opensilex.org:8080/weisAPI/rest*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_calls**](Brapiv1callsApi.md#get_calls) | **GET** /brapi/v1/calls | Check the available BrAPI calls


# **get_calls**
> list[Call] get_calls(page_size=page_size, page=page, data_type=data_type)

Check the available BrAPI calls

Check the available BrAPI calls

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.Brapiv1callsApi(pythonClient)
page_size = 20 # int | Number of elements per page (limited to 150000) (optional) (default to 20)
page = 0 # int | Current page number (optional) (default to 0)
data_type = '\"json\"' # str | The data format supported by the call (optional)


try:
    # Check the available BrAPI calls
    api_response = api_instance.get_calls(page_size=page_size, page=page, data_type=data_type)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling Brapiv1callsApi->get_calls: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page_size** | **int**| Number of elements per page (limited to 150000) | [optional] [default to 20]
 **page** | **int**| Current page number | [optional] [default to 0]
 **data_type** | **str**| The data format supported by the call | [optional] 


### Return type

[**list[Call]**](Call.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

