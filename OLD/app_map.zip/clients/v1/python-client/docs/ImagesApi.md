# WeisWSClient.ImagesApi

All URIs are relative to *http://www.opensilex.org:8080/weisAPI/rest*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_images_by_search**](ImagesApi.md#get_images_by_search) | **GET** /images | Get all images corresponding to the search params given
[**post_image_file**](ImagesApi.md#post_image_file) | **POST** /images/upload | Post data file
[**post_images_metadata**](ImagesApi.md#post_images_metadata) | **POST** /images | Save a file


# **get_images_by_search**
> list[ImageMetadata] get_images_by_search(authorization, page_size=page_size, page=page, uri=uri, rdf_type=rdf_type, concerned_items=concerned_items, start_date=start_date, end_date=end_date, sensor=sensor)

Get all images corresponding to the search params given



### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.ImagesApi(pythonClient)
page_size = 20 # int | Number of elements per page (limited to 150000) (optional) (default to 20)
page = 0 # int | Current page number (optional) (default to 0)
uri = '\"http://www.opensilex.org/demo/2017/i170000000000\"' # str | Search by image uri (optional)
rdf_type = '\"http://www.opensilex.org/vocabulary/oeso#HemisphericalImage\"' # str | Search by image type (optional)
concerned_items = '\"http://www.opensilex.org/demo/2018/o18000076;http://www.opensilex.org/demo/2018/o18000076\"' # str | Search by concerned item uri - each concerned item uri must be separated by \";\" (optional)
start_date = '\"2017-06-15 10:51:00+0200\"' # str | Search by interval - start date (optional)
end_date = '\"2017-06-15 10:51:00+0200\"' # str | Search by interval - end date (optional)
sensor = '\"http://www.opensilex.org/demo/2018/s18001\"' # str | Search by sensor (optional)


try:
    # Get all images corresponding to the search params given
    api_response = api_instance.get_images_by_search(page_size=page_size, page=page, uri=uri, rdf_type=rdf_type, concerned_items=concerned_items, start_date=start_date, end_date=end_date, sensor=sensor)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ImagesApi->get_images_by_search: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page_size** | **int**| Number of elements per page (limited to 150000) | [optional] [default to 20]
 **page** | **int**| Current page number | [optional] [default to 0]
 **uri** | **str**| Search by image uri | [optional] 
 **rdf_type** | **str**| Search by image type | [optional] 
 **concerned_items** | **str**| Search by concerned item uri - each concerned item uri must be separated by \&quot;;\&quot; | [optional] 
 **start_date** | **str**| Search by interval - start date | [optional] 
 **end_date** | **str**| Search by interval - end date | [optional] 
 **sensor** | **str**| Search by sensor | [optional] 


### Return type

[**list[ImageMetadata]**](ImageMetadata.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post_image_file**
> ResponseFormPOST post_image_file(authorization, body=body, uri=uri)

Post data file

This can only be done by a PHIS-SILEX user. Not working from this documentation. Implement a client or use Postman application.

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.ImagesApi(pythonClient)
body = '/path/to/file.txt' # file | File to upload (optional)
uri = 'uri_example' # str | Uri given from \"images\" path for upload (optional)


try:
    # Post data file
    api_response = api_instance.post_image_file(body=body, uri=uri)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ImagesApi->post_image_file: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | **file**| File to upload | [optional] 
 **uri** | **str**| Uri given from \&quot;images\&quot; path for upload | [optional] 


### Return type

[**ResponseFormPOST**](ResponseFormPOST.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/octet-stream
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post_images_metadata**
> list[ImageMetadataDTO] post_images_metadata(body, authorization)

Save a file

This can only be done by a PHIS-SILEX admin.

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.ImagesApi(pythonClient)
body = [WeisWSClient.ImageMetadataDTO()] # list[ImageMetadataDTO] | JSON Image metadata


try:
    # Save a file
    api_response = api_instance.post_images_metadata(body, )
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ImagesApi->post_images_metadata: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**list[ImageMetadataDTO]**](ImageMetadataDTO.md)| JSON Image metadata | 


### Return type

[**list[ImageMetadataDTO]**](ImageMetadataDTO.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

