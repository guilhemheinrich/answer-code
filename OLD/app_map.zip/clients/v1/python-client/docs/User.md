# User

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**email** | **str** |  | [optional] 
**family_name** | **str** |  | [optional] 
**phone** | **str** |  | [optional] 
**affiliation** | **str** |  | [optional] 
**uri** | **str** |  | [optional] 
**orcid** | **str** |  | [optional] 
**groups** | [**list[Group]**](Group.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


