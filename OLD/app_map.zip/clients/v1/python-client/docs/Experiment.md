# Experiment

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**uri** | **str** |  | [optional] 
**start_date** | **str** |  | [optional] 
**end_date** | **str** |  | [optional] 
**field** | **str** |  | [optional] 
**campaign** | **str** |  | [optional] 
**place** | **str** |  | [optional] 
**alias** | **str** |  | [optional] 
**comment** | **str** |  | [optional] 
**keywords** | **str** |  | [optional] 
**objective** | **str** |  | [optional] 
**crop_species** | **str** |  | [optional] 
**projects** | [**list[Project]**](Project.md) |  | [optional] 
**groups** | [**list[Group]**](Group.md) |  | [optional] 
**contacts** | [**list[ContactPostgreSQL]**](ContactPostgreSQL.md) |  | [optional] 
**variables** | **dict(str, str)** |  | [optional] 
**sensors** | **dict(str, str)** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


