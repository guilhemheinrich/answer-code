# ProjectPostDTO

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** |  | [optional] 
**shortname** | **str** |  | [optional] 
**related_projects** | **list[str]** |  | [optional] 
**financial_funding** | **str** |  | [optional] 
**financial_reference** | **str** |  | [optional] 
**description** | **str** |  | [optional] 
**start_date** | **str** |  | [optional] 
**end_date** | **str** |  | [optional] 
**keywords** | **list[str]** |  | [optional] 
**home_page** | **str** |  | [optional] 
**administrative_contacts** | **list[str]** |  | [optional] 
**coordinators** | **list[str]** |  | [optional] 
**scientific_contacts** | **list[str]** |  | [optional] 
**objective** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


