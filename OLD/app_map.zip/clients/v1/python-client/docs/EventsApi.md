# WeisWSClient.EventsApi

All URIs are relative to *http://www.opensilex.org:8080/weisAPI/rest*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_event_annotations**](EventsApi.md#get_event_annotations) | **GET** /events/{uri}/annotations | Get an event&#39;s annotations
[**get_event_by_uri**](EventsApi.md#get_event_by_uri) | **GET** /events/{uri} | Get the event corresponding to the search uri
[**get_events**](EventsApi.md#get_events) | **GET** /events | Get all events corresponding to the search parameters given.
[**post2**](EventsApi.md#post2) | **POST** /events | POST event(s)
[**put1**](EventsApi.md#put1) | **PUT** /events | Update events


# **get_event_annotations**
> list[RdfResourceDefinitionDTO] get_event_annotations(uri, authorization, page_size=page_size, page=page)

Get an event's annotations

Get an event's annotations

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.EventsApi(pythonClient)
uri = '\"http://www.opensilex.org/id/event/12590c87-1c34-426b-a231-beb7acb33415\"' # str | An event URI (Unique Resource Identifier)
page_size = 20 # int | Number of elements per page (limited to 150000) (optional) (default to 20)
page = 0 # int | Current page number (optional) (default to 0)


try:
    # Get an event's annotations
    api_response = api_instance.get_event_annotations(uri, page_size=page_size, page=page)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling EventsApi->get_event_annotations: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **uri** | **str**| An event URI (Unique Resource Identifier) | 
 **page_size** | **int**| Number of elements per page (limited to 150000) | [optional] [default to 20]
 **page** | **int**| Current page number | [optional] [default to 0]


### Return type

[**list[RdfResourceDefinitionDTO]**](RdfResourceDefinitionDTO.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_event_by_uri**
> list[EventGetDTO] get_event_by_uri(uri, authorization)

Get the event corresponding to the search uri

Get the event corresponding to the search uri

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.EventsApi(pythonClient)
uri = '\"http://www.opensilex.org/id/event/12590c87-1c34-426b-a231-beb7acb33415\"' # str | An event URI (Unique Resource Identifier)


try:
    # Get the event corresponding to the search uri
    api_response = api_instance.get_event_by_uri(uri, )
    pprint(api_response)
except ApiException as e:
    print("Exception when calling EventsApi->get_event_by_uri: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **uri** | **str**| An event URI (Unique Resource Identifier) | 


### Return type

[**list[EventGetDTO]**](EventGetDTO.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_events**
> list[EventGetDTO] get_events(authorization, page_size=page_size, page=page, uri=uri, type=type, concerned_item_uri=concerned_item_uri, concerned_item_label=concerned_item_label, start_date=start_date, end_date=end_date)

Get all events corresponding to the search parameters given.

Retrieve all events authorized for the user corresponding to the search parameters given

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.EventsApi(pythonClient)
page_size = 20 # int | Number of elements per page (limited to 150000) (optional) (default to 20)
page = 0 # int | Current page number (optional) (default to 0)
uri = '\"http://www.opensilex.org/id/event/12590c87-1c34-426b-a231-beb7acb33415\"' # str | Search by uri (optional)
type = '\"http://www.opensilex.org/vocabulary/oeev#MoveFrom\"' # str | Search by type (optional)
concerned_item_uri = '\"http://www.opensilex.org/m3p/arch/2017/c17000242\"' # str | Search by concerned item uri (optional)
concerned_item_label = '\"Plot Lavalette\"' # str | Search by concerned item label (optional)
start_date = '\"2017-09-08T12:00:00+01:00\"' # str | Search by date - start of the range (optional)
end_date = '\"2019-10-08T12:00:00+01:00\"' # str | Search by date - end of the range (optional)


try:
    # Get all events corresponding to the search parameters given.
    api_response = api_instance.get_events(page_size=page_size, page=page, uri=uri, type=type, concerned_item_uri=concerned_item_uri, concerned_item_label=concerned_item_label, start_date=start_date, end_date=end_date)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling EventsApi->get_events: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page_size** | **int**| Number of elements per page (limited to 150000) | [optional] [default to 20]
 **page** | **int**| Current page number | [optional] [default to 0]
 **uri** | **str**| Search by uri | [optional] 
 **type** | **str**| Search by type | [optional] 
 **concerned_item_uri** | **str**| Search by concerned item uri | [optional] 
 **concerned_item_label** | **str**| Search by concerned item label | [optional] 
 **start_date** | **str**| Search by date - start of the range | [optional] 
 **end_date** | **str**| Search by date - end of the range | [optional] 


### Return type

[**list[EventGetDTO]**](EventGetDTO.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post2**
> ResponseFormPOST post2(authorization, body=body)

POST event(s)

Register event(s)

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.EventsApi(pythonClient)
body = [WeisWSClient.EventPostDTO()] # list[EventPostDTO] | JSON format of a list of events without URIs (optional)


try:
    # POST event(s)
    api_response = api_instance.post2(body=body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling EventsApi->post2: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**list[EventPostDTO]**](EventPostDTO.md)| JSON format of a list of events without URIs | [optional] 


### Return type

[**ResponseFormPOST**](ResponseFormPOST.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **put1**
> ResponseFormPOST put1(authorization, body=body)

Update events



### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.EventsApi(pythonClient)
body = [WeisWSClient.EventPutDTO()] # list[EventPutDTO] | JSON format of a list of events with URIs (optional)


try:
    # Update events
    api_response = api_instance.put1(body=body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling EventsApi->put1: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**list[EventPutDTO]**](EventPutDTO.md)| JSON format of a list of events with URIs | [optional] 


### Return type

[**ResponseFormPOST**](ResponseFormPOST.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

