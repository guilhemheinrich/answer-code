# WeisWSClient.Brapiv1studiesSearchApi

All URIs are relative to *http://www.opensilex.org:8080/weisAPI/rest*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_studies_search**](Brapiv1studiesSearchApi.md#get_studies_search) | **GET** /brapi/v1/studies-search | Retrieve studies information
[**post_studies_search**](Brapiv1studiesSearchApi.md#post_studies_search) | **POST** /brapi/v1/studies-search | search studies


# **get_studies_search**
> list[StudyDTO] get_studies_search(authorization, study_db_id=study_db_id, common_crop_name=common_crop_name, season_db_id=season_db_id, active=active, sort_by=sort_by, sort_order=sort_order, page_size=page_size, page=page)

Retrieve studies information

Retrieve studies information

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.Brapiv1studiesSearchApi(pythonClient)
study_db_id = '\"http://www.opensilex.org/demo/DMO2012-1\"' # str | Search by studyDbId (optional)
common_crop_name = '\"maize\"' # str | Search by commonCropName (optional)
season_db_id = '\"2012\"' # str | Search by seasonDbId (optional)
active = 'active_example' # str | Filter active status true/false (optional)
sort_by = 'sort_by_example' # str | Name of the field to sort by: studyDbId, commonCropName or seasonDbId (optional)
sort_order = 'sort_order_example' # str | Sort order direction - ASC or DESC (optional)
page_size = 20 # int | Number of elements per page (limited to 150000) (optional) (default to 20)
page = 0 # int | Current page number (optional) (default to 0)


try:
    # Retrieve studies information
    api_response = api_instance.get_studies_search(study_db_id=study_db_id, common_crop_name=common_crop_name, season_db_id=season_db_id, active=active, sort_by=sort_by, sort_order=sort_order, page_size=page_size, page=page)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling Brapiv1studiesSearchApi->get_studies_search: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **study_db_id** | **str**| Search by studyDbId | [optional] 
 **common_crop_name** | **str**| Search by commonCropName | [optional] 
 **season_db_id** | **str**| Search by seasonDbId | [optional] 
 **active** | **str**| Filter active status true/false | [optional] 
 **sort_by** | **str**| Name of the field to sort by: studyDbId, commonCropName or seasonDbId | [optional] 
 **sort_order** | **str**| Sort order direction - ASC or DESC | [optional] 
 **page_size** | **int**| Number of elements per page (limited to 150000) | [optional] [default to 20]
 **page** | **int**| Current page number | [optional] [default to 0]


### Return type

[**list[StudyDTO]**](StudyDTO.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post_studies_search**
> ResponseFormPOST post_studies_search(authorization, body=body)

search studies

search studies

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.Brapiv1studiesSearchApi(pythonClient)
body = WeisWSClient.StudySearchDTO() # StudySearchDTO | JSON format of experiment data (optional)


try:
    # search studies
    api_response = api_instance.post_studies_search(body=body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling Brapiv1studiesSearchApi->post_studies_search: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**StudySearchDTO**](StudySearchDTO.md)| JSON format of experiment data | [optional] 


### Return type

[**ResponseFormPOST**](ResponseFormPOST.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

