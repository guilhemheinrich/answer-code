# ScientificObjectDTO

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**uri** | **str** |  | [optional] 
**rdf_type** | **str** |  | [optional] 
**geometry** | **str** |  | [optional] 
**experiment** | **str** |  | [optional] 
**is_part_of** | **str** |  | [optional] 
**label** | **str** |  | [optional] 
**properties** | [**list[PropertyDTO]**](PropertyDTO.md) |  | [optional] 
**uri_experiment** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


