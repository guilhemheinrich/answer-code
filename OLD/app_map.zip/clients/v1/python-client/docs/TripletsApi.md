# WeisWSClient.TripletsApi

All URIs are relative to *http://www.opensilex.org:8080/weisAPI/rest*

Method | HTTP request | Description
------------- | ------------- | -------------
[**post_triplets**](TripletsApi.md#post_triplets) | **POST** /triplets | Post triplets


# **post_triplets**
> ResponseFormPOST post_triplets(body, authorization)

Post triplets

Register new triplets in the triplestore

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.TripletsApi(pythonClient)
body = [WeisWSClient.list[list[TripletDTO]]()] # list[list[TripletDTO]] | JSON format of a triplet


try:
    # Post triplets
    api_response = api_instance.post_triplets(body, )
    pprint(api_response)
except ApiException as e:
    print("Exception when calling TripletsApi->post_triplets: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | **list[list[TripletDTO]]**| JSON format of a triplet | 


### Return type

[**ResponseFormPOST**](ResponseFormPOST.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

