# ContactBrapi

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**contact_db_id** | **str** |  | [optional] 
**name** | **str** |  | [optional] 
**institute_name** | **str** |  | [optional] 
**email** | **str** |  | [optional] 
**type** | **str** |  | [optional] 
**orcid** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


