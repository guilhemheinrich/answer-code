# TripletDTO

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**s** | **str** |  | [optional] 
**p** | **str** |  | [optional] 
**o** | **str** |  | [optional] 
**o_type** | **str** |  | [optional] 
**o_lang** | **str** |  | [optional] 
**g** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


