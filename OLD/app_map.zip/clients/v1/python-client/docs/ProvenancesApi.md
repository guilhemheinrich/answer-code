# WeisWSClient.ProvenancesApi

All URIs are relative to *http://www.opensilex.org:8080/weisAPI/rest*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_provenances**](ProvenancesApi.md#get_provenances) | **GET** /provenances | Get all provenances corresponding to the search params given
[**post4**](ProvenancesApi.md#post4) | **POST** /provenances | Post provenance(s)
[**put3**](ProvenancesApi.md#put3) | **PUT** /provenances | Update provenance


# **get_provenances**
> list[ProvenanceDTO] get_provenances(authorization, page_size=page_size, page=page, uri=uri, label=label, comment=comment, json_value_filter=json_value_filter)

Get all provenances corresponding to the search params given

Retrieve all provenances authorized for the user corresponding to the searched params given

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.ProvenancesApi(pythonClient)
page_size = 20 # int | Number of elements per page (limited to 150000) (optional) (default to 20)
page = 0 # int | Current page number (optional) (default to 0)
uri = '\"http://www.opensilex.org/demo/2018/pv181515071552\"' # str | Search by provenance uri (optional)
label = '\"PROV2019-LEAF\"' # str | Search by provenance label (optional)
comment = '\"In this provenance we have count the number of leaf per plant\"' # str | Search by comment (optional)
json_value_filter = '\"{ \\\"SensingDevice\\\" : \\\"http://www.opensilex.org/demo/s001\\\",\\n\\\"Vector\\\" : \\\"http://www.opensilex.org/demo/v001\\\"}\"' # str | Search by json filter (optional)


try:
    # Get all provenances corresponding to the search params given
    api_response = api_instance.get_provenances(page_size=page_size, page=page, uri=uri, label=label, comment=comment, json_value_filter=json_value_filter)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ProvenancesApi->get_provenances: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page_size** | **int**| Number of elements per page (limited to 150000) | [optional] [default to 20]
 **page** | **int**| Current page number | [optional] [default to 0]
 **uri** | **str**| Search by provenance uri | [optional] 
 **label** | **str**| Search by provenance label | [optional] 
 **comment** | **str**| Search by comment | [optional] 
 **json_value_filter** | **str**| Search by json filter | [optional] 


### Return type

[**list[ProvenanceDTO]**](ProvenanceDTO.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post4**
> ResponseFormPOST post4(authorization, body=body)

Post provenance(s)

Register provenance(s) in the database

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.ProvenancesApi(pythonClient)
body = [WeisWSClient.ProvenancePostDTO()] # list[ProvenancePostDTO] | JSON format of provenance (optional)


try:
    # Post provenance(s)
    api_response = api_instance.post4(body=body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ProvenancesApi->post4: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**list[ProvenancePostDTO]**](ProvenancePostDTO.md)| JSON format of provenance | [optional] 


### Return type

[**ResponseFormPOST**](ResponseFormPOST.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **put3**
> ResponseFormPOST put3(authorization, body=body)

Update provenance



### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.ProvenancesApi(pythonClient)
body = [WeisWSClient.ProvenanceDTO()] # list[ProvenanceDTO] | JSON format of provenance (optional)


try:
    # Update provenance
    api_response = api_instance.put3(body=body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ProvenancesApi->put3: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**list[ProvenanceDTO]**](ProvenanceDTO.md)| JSON format of provenance | [optional] 


### Return type

[**ResponseFormPOST**](ResponseFormPOST.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

