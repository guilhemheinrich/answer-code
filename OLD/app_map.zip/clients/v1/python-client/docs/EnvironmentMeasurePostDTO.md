# EnvironmentMeasurePostDTO

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sensor_uri** | **str** |  | [optional] 
**variable_uri** | **str** |  | [optional] 
**_date** | **str** |  | [optional] 
**value** | **float** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


