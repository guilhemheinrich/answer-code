# WeisWSClient.MethodsApi

All URIs are relative to *http://www.opensilex.org:8080/weisAPI/rest*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_method_details**](MethodsApi.md#get_method_details) | **GET** /methods/{method} | Get a method
[**get_methods_by_search**](MethodsApi.md#get_methods_by_search) | **GET** /methods | Get all methods corresponding to the searched params given
[**post_method**](MethodsApi.md#post_method) | **POST** /methods | Post method(s)
[**put_method**](MethodsApi.md#put_method) | **PUT** /methods | Update method


# **get_method_details**
> list[Method] get_method_details(method, authorization, page_size=page_size, page=page)

Get a method

Retrieve a method. Need URL encoded method URI (Unique resource identifier).

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.MethodsApi(pythonClient)
method = '\"http://www.opensilex.org/demo/id/methods/m001\"' # str | A method URI (Unique Resource Identifier)
page_size = 20 # int | Number of elements per page (limited to 150000) (optional) (default to 20)
page = 0 # int | Current page number (optional) (default to 0)


try:
    # Get a method
    api_response = api_instance.get_method_details(method, page_size=page_size, page=page)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling MethodsApi->get_method_details: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **method** | **str**| A method URI (Unique Resource Identifier) | 
 **page_size** | **int**| Number of elements per page (limited to 150000) | [optional] [default to 20]
 **page** | **int**| Current page number | [optional] [default to 0]


### Return type

[**list[Method]**](Method.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_methods_by_search**
> list[Method] get_methods_by_search(authorization, page_size=page_size, page=page, uri=uri, label=label)

Get all methods corresponding to the searched params given

Retrieve all methods authorized for the user corresponding to the user corresponding to the searched params given

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.MethodsApi(pythonClient)
page_size = 20 # int | Number of elements per page (limited to 150000) (optional) (default to 20)
page = 0 # int | Current page number (optional) (default to 0)
uri = '\"http://www.opensilex.org/demo/id/methods/m001\"' # str | Search by URI (optional)
label = '\"comptage\"' # str | Search by label (optional)


try:
    # Get all methods corresponding to the searched params given
    api_response = api_instance.get_methods_by_search(page_size=page_size, page=page, uri=uri, label=label)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling MethodsApi->get_methods_by_search: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page_size** | **int**| Number of elements per page (limited to 150000) | [optional] [default to 20]
 **page** | **int**| Current page number | [optional] [default to 0]
 **uri** | **str**| Search by URI | [optional] 
 **label** | **str**| Search by label | [optional] 


### Return type

[**list[Method]**](Method.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post_method**
> ResponseFormPOST post_method(authorization, body=body)

Post method(s)

Register new method(s) in the data base

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.MethodsApi(pythonClient)
body = [WeisWSClient.MethodDTO()] # list[MethodDTO] | JSON format of method (optional)


try:
    # Post method(s)
    api_response = api_instance.post_method(body=body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling MethodsApi->post_method: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**list[MethodDTO]**](MethodDTO.md)| JSON format of method | [optional] 


### Return type

[**ResponseFormPOST**](ResponseFormPOST.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **put_method**
> ResponseFormPOST put_method(authorization, body=body)

Update method



### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.MethodsApi(pythonClient)
body = [WeisWSClient.MethodDTO()] # list[MethodDTO] | JSON format of method (optional)


try:
    # Update method
    api_response = api_instance.put_method(body=body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling MethodsApi->put_method: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**list[MethodDTO]**](MethodDTO.md)| JSON format of method | [optional] 


### Return type

[**ResponseFormPOST**](ResponseFormPOST.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

