# WeisWSClient.Brapiv1studiesApi

All URIs are relative to *http://www.opensilex.org:8080/weisAPI/rest*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_observation_units**](Brapiv1studiesApi.md#get_observation_units) | **GET** /brapi/v1/studies/{studyDbId}/observationunits | List all the observation units measured in the study.
[**get_observation_variables**](Brapiv1studiesApi.md#get_observation_variables) | **GET** /brapi/v1/studies/{studyDbId}/observationvariables | List all the observation variables measured in the study.
[**get_observations**](Brapiv1studiesApi.md#get_observations) | **GET** /brapi/v1/studies/{studyDbId}/observations | Get the observations associated to a specific study
[**get_studies**](Brapiv1studiesApi.md#get_studies) | **GET** /brapi/v1/studies | Retrieve studies information
[**get_study_details**](Brapiv1studiesApi.md#get_study_details) | **GET** /brapi/v1/studies/{studyDbId} | Retrieve study details


# **get_observation_units**
> list[BrapiObservationUnitDTO] get_observation_units(study_db_id, authorization, observation_level=observation_level, page_size=page_size, page=page)

List all the observation units measured in the study.

List all the observation units measured in the study.

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.Brapiv1studiesApi(pythonClient)
study_db_id = '\"http://www.opensilex.org/demo/DMO2012-1\"' # str | studyDbId
observation_level = '\"Plot\"' # str | observationLevel (optional)
page_size = 20 # int | Number of elements per page (limited to 150000) (optional) (default to 20)
page = 0 # int | Current page number (optional) (default to 0)


try:
    # List all the observation units measured in the study.
    api_response = api_instance.get_observation_units(study_db_id, observation_level=observation_level, page_size=page_size, page=page)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling Brapiv1studiesApi->get_observation_units: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **study_db_id** | **str**| studyDbId | 
 **observation_level** | **str**| observationLevel | [optional] 
 **page_size** | **int**| Number of elements per page (limited to 150000) | [optional] [default to 20]
 **page** | **int**| Current page number | [optional] [default to 0]


### Return type

[**list[BrapiObservationUnitDTO]**](BrapiObservationUnitDTO.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_observation_variables**
> list[BrapiVariable] get_observation_variables(study_db_id, authorization, page_size=page_size, page=page)

List all the observation variables measured in the study.

List all the observation variables measured in the study.

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.Brapiv1studiesApi(pythonClient)
study_db_id = '\"http://www.opensilex.org/demo/DMO2012-1\"' # str | studyDbId
page_size = 20 # int | Number of elements per page (limited to 150000) (optional) (default to 20)
page = 0 # int | Current page number (optional) (default to 0)


try:
    # List all the observation variables measured in the study.
    api_response = api_instance.get_observation_variables(study_db_id, page_size=page_size, page=page)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling Brapiv1studiesApi->get_observation_variables: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **study_db_id** | **str**| studyDbId | 
 **page_size** | **int**| Number of elements per page (limited to 150000) | [optional] [default to 20]
 **page** | **int**| Current page number | [optional] [default to 0]


### Return type

[**list[BrapiVariable]**](BrapiVariable.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_observations**
> list[BrapiObservationDTO] get_observations(study_db_id, authorization, observation_variable_db_ids=observation_variable_db_ids, page_size=page_size, page=page)

Get the observations associated to a specific study

Get the observations associated to a specific study

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.Brapiv1studiesApi(pythonClient)
study_db_id = '\"http://www.opensilex.org/demo/DMO2012-1\"' # str | studyDbId
observation_variable_db_ids = ['observation_variable_db_ids_example'] # list[str] | observationVariableDbIds (optional)
page_size = 20 # int | Number of elements per page (limited to 150000) (optional) (default to 20)
page = 0 # int | Current page number (optional) (default to 0)


try:
    # Get the observations associated to a specific study
    api_response = api_instance.get_observations(study_db_id, observation_variable_db_ids=observation_variable_db_ids, page_size=page_size, page=page)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling Brapiv1studiesApi->get_observations: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **study_db_id** | **str**| studyDbId | 
 **observation_variable_db_ids** | [**list[str]**](str.md)| observationVariableDbIds | [optional] 
 **page_size** | **int**| Number of elements per page (limited to 150000) | [optional] [default to 20]
 **page** | **int**| Current page number | [optional] [default to 0]


### Return type

[**list[BrapiObservationDTO]**](BrapiObservationDTO.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_studies**
> list[StudyDTO] get_studies(authorization, study_db_id=study_db_id, common_crop_name=common_crop_name, season_db_id=season_db_id, active=active, sort_by=sort_by, sort_order=sort_order, page_size=page_size, page=page)

Retrieve studies information

Retrieve studies information

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.Brapiv1studiesApi(pythonClient)
study_db_id = '\"http://www.opensilex.org/demo/DMO2012-1\"' # str | Search by studyDbId (optional)
common_crop_name = '\"maize\"' # str | Search by commonCropName (optional)
season_db_id = '\"2012\"' # str | Search by seasonDbId (optional)
active = 'active_example' # str | Filter active status true/false (optional)
sort_by = 'sort_by_example' # str | Name of the field to sort by: studyDbId, commonCropName or seasonDbId (optional)
sort_order = 'sort_order_example' # str | Sort order direction - ASC or DESC (optional)
page_size = 20 # int | Number of elements per page (limited to 150000) (optional) (default to 20)
page = 0 # int | Current page number (optional) (default to 0)


try:
    # Retrieve studies information
    api_response = api_instance.get_studies(study_db_id=study_db_id, common_crop_name=common_crop_name, season_db_id=season_db_id, active=active, sort_by=sort_by, sort_order=sort_order, page_size=page_size, page=page)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling Brapiv1studiesApi->get_studies: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **study_db_id** | **str**| Search by studyDbId | [optional] 
 **common_crop_name** | **str**| Search by commonCropName | [optional] 
 **season_db_id** | **str**| Search by seasonDbId | [optional] 
 **active** | **str**| Filter active status true/false | [optional] 
 **sort_by** | **str**| Name of the field to sort by: studyDbId, commonCropName or seasonDbId | [optional] 
 **sort_order** | **str**| Sort order direction - ASC or DESC | [optional] 
 **page_size** | **int**| Number of elements per page (limited to 150000) | [optional] [default to 20]
 **page** | **int**| Current page number | [optional] [default to 0]


### Return type

[**list[StudyDTO]**](StudyDTO.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_study_details**
> list[StudyDetails] get_study_details(study_db_id, authorization)

Retrieve study details

Retrieve study details

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.Brapiv1studiesApi(pythonClient)
study_db_id = '\"http://www.opensilex.org/demo/DMO2012-1\"' # str | Search by studyDbId


try:
    # Retrieve study details
    api_response = api_instance.get_study_details(study_db_id, )
    pprint(api_response)
except ApiException as e:
    print("Exception when calling Brapiv1studiesApi->get_study_details: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **study_db_id** | **str**| Search by studyDbId | 


### Return type

[**list[StudyDetails]**](StudyDetails.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

