# WeisWSClient.UserApi

All URIs are relative to *http://www.opensilex.org:8080/weisAPI/rest*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_user_by_search**](UserApi.md#get_user_by_search) | **GET** /users | Get all users corresponding to the searched params given
[**get_user_details**](UserApi.md#get_user_details) | **GET** /users/{userEmail} | Get a user
[**post_user**](UserApi.md#post_user) | **POST** /users | Post a user
[**put_user**](UserApi.md#put_user) | **PUT** /users | Update users


# **get_user_by_search**
> list[User] get_user_by_search(authorization, page_size=page_size, page=page, email=email, first_name=first_name, family_name=family_name, address=address, phone=phone, affiliation=affiliation, orcid=orcid, admin=admin, available=available, uri=uri)

Get all users corresponding to the searched params given

Retrieve all users authorized for the user corresponding to the searched params given

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.UserApi(pythonClient)
page_size = 20 # int | Number of elements per page (limited to 150000) (optional) (default to 20)
page = 0 # int | Current page number (optional) (default to 0)
email = '\"admin@opensilex.org\"' # str | Search by email (optional)
first_name = '\"Marie\"' # str | Search by first name (optional)
family_name = '\"Dupont\"' # str | Search by family name (optional)
address = '\"2 place Pierre Viala, Montpellier\"' # str | Search by address (optional)
phone = '\"0400000000\"' # str | Search by phone (optional)
affiliation = '\"affiliation\"' # str | Search by affiliation (optional)
orcid = '\"orcid\"' # str | Search by orcid (optional)
admin = '\"true\"' # str | Search by admin (optional)
available = '\"true\"' # str | Search by available (optional)
uri = '\"http://www.opensilex.org/demo/id/agent/marie_dupond\"' # str | Search by uri (optional)


try:
    # Get all users corresponding to the searched params given
    api_response = api_instance.get_user_by_search(page_size=page_size, page=page, email=email, first_name=first_name, family_name=family_name, address=address, phone=phone, affiliation=affiliation, orcid=orcid, admin=admin, available=available, uri=uri)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling UserApi->get_user_by_search: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page_size** | **int**| Number of elements per page (limited to 150000) | [optional] [default to 20]
 **page** | **int**| Current page number | [optional] [default to 0]
 **email** | **str**| Search by email | [optional] 
 **first_name** | **str**| Search by first name | [optional] 
 **family_name** | **str**| Search by family name | [optional] 
 **address** | **str**| Search by address | [optional] 
 **phone** | **str**| Search by phone | [optional] 
 **affiliation** | **str**| Search by affiliation | [optional] 
 **orcid** | **str**| Search by orcid | [optional] 
 **admin** | **str**| Search by admin | [optional] 
 **available** | **str**| Search by available | [optional] 
 **uri** | **str**| Search by uri | [optional] 


### Return type

[**list[User]**](User.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_user_details**
> list[User] get_user_details(user_email, authorization, page_size=page_size, page=page)

Get a user

Retrieve a user. Need user email

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.UserApi(pythonClient)
user_email = '\"admin@opensilex.org\"' # str | A user email
page_size = 20 # int | Number of elements per page (limited to 150000) (optional) (default to 20)
page = 0 # int | Current page number (optional) (default to 0)


try:
    # Get a user
    api_response = api_instance.get_user_details(user_email, page_size=page_size, page=page)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling UserApi->get_user_details: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **user_email** | **str**| A user email | 
 **page_size** | **int**| Number of elements per page (limited to 150000) | [optional] [default to 20]
 **page** | **int**| Current page number | [optional] [default to 0]


### Return type

[**list[User]**](User.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post_user**
> ResponseFormPOST post_user(authorization, body=body)

Post a user

Register a new user in the database

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.UserApi(pythonClient)
body = [WeisWSClient.UserDTO()] # list[UserDTO] | JSON format of user data (optional)


try:
    # Post a user
    api_response = api_instance.post_user(body=body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling UserApi->post_user: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**list[UserDTO]**](UserDTO.md)| JSON format of user data | [optional] 


### Return type

[**ResponseFormPOST**](ResponseFormPOST.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **put_user**
> ResponseFormPOST put_user(authorization, body=body)

Update users



### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.UserApi(pythonClient)
body = [WeisWSClient.UserDTO()] # list[UserDTO] | JSON format of user data (optional)


try:
    # Update users
    api_response = api_instance.put_user(body=body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling UserApi->put_user: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**list[UserDTO]**](UserDTO.md)| JSON format of user data | [optional] 


### Return type

[**ResponseFormPOST**](ResponseFormPOST.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

