# WeisWSClient.ScientificObjectsApi

All URIs are relative to *http://www.opensilex.org:8080/weisAPI/rest*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_scientific_objects_by_search**](ScientificObjectsApi.md#get_scientific_objects_by_search) | **GET** /scientificObjects | Get all scientific objects corresponding to the searched params given
[**post_scientific_object**](ScientificObjectsApi.md#post_scientific_object) | **POST** /scientificObjects | Post scientific object(s)
[**put5**](ScientificObjectsApi.md#put5) | **PUT** /scientificObjects/{uri}/{experiment} | Put scientific object(s) in the given experiment


# **get_scientific_objects_by_search**
> list[ScientificObjectDTO] get_scientific_objects_by_search(authorization, page_size=page_size, page=page, uri=uri, experiment=experiment, alias=alias, rdf_type=rdf_type, with_properties=with_properties)

Get all scientific objects corresponding to the searched params given

Retrieve all scientific objects authorized for the user corresponding to the user corresponding to the searched params given

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.ScientificObjectsApi(pythonClient)
page_size = 20 # int | Number of elements per page (limited to 150000) (optional) (default to 20)
page = 0 # int | Current page number (optional) (default to 0)
uri = '\"http://www.opensilex.org/demo/2018/o18000076\"' # str | Search by URI (optional)
experiment = '\"http://www.opensilex.org/demo/DMO2012-1\"' # str | Search by experiment URI (optional)
alias = '\"alias\"' # str | Search by alias (optional)
rdf_type = '\"http://www.opensilex.org/vocabulary/oeso#Plot\"' # str | Search by rdfType (optional)
with_properties = true # bool | Retreive detailled properties (optional) (default to true)


try:
    # Get all scientific objects corresponding to the searched params given
    api_response = api_instance.get_scientific_objects_by_search(page_size=page_size, page=page, uri=uri, experiment=experiment, alias=alias, rdf_type=rdf_type, with_properties=with_properties)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ScientificObjectsApi->get_scientific_objects_by_search: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page_size** | **int**| Number of elements per page (limited to 150000) | [optional] [default to 20]
 **page** | **int**| Current page number | [optional] [default to 0]
 **uri** | **str**| Search by URI | [optional] 
 **experiment** | **str**| Search by experiment URI | [optional] 
 **alias** | **str**| Search by alias | [optional] 
 **rdf_type** | **str**| Search by rdfType | [optional] 
 **with_properties** | **bool**| Retreive detailled properties | [optional] [default to true]


### Return type

[**list[ScientificObjectDTO]**](ScientificObjectDTO.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post_scientific_object**
> ResponseFormPOST post_scientific_object(body, authorization)

Post scientific object(s)

Register new scientific object(s) in the database.

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.ScientificObjectsApi(pythonClient)
body = [WeisWSClient.ScientificObjectPostDTO()] # list[ScientificObjectPostDTO] | JSON format of scientific object data


try:
    # Post scientific object(s)
    api_response = api_instance.post_scientific_object(body, )
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ScientificObjectsApi->post_scientific_object: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**list[ScientificObjectPostDTO]**](ScientificObjectPostDTO.md)| JSON format of scientific object data | 


### Return type

[**ResponseFormPOST**](ResponseFormPOST.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **put5**
> ResponseFormPOST put5(uri, experiment, body, authorization)

Put scientific object(s) in the given experiment

Update scientific object(s) in the database.

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.ScientificObjectsApi(pythonClient)
uri = '\"http://www.opensilex.org/demo/2018/o18000076\"' # str | Scientific object URI (Unique Resource Identifier)
experiment = '\"http://www.opensilex.org/demo/DMO2012-1\"' # str | An experiment URI (Unique Resource Identifier)
body = WeisWSClient.ScientificObjectPutDTO() # ScientificObjectPutDTO | JSON format of scientific object data


try:
    # Put scientific object(s) in the given experiment
    api_response = api_instance.put5(uri, experiment, body, )
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ScientificObjectsApi->put5: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **uri** | **str**| Scientific object URI (Unique Resource Identifier) | 
 **experiment** | **str**| An experiment URI (Unique Resource Identifier) | 
 **body** | [**ScientificObjectPutDTO**](ScientificObjectPutDTO.md)| JSON format of scientific object data | 


### Return type

[**ResponseFormPOST**](ResponseFormPOST.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

