# Data

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**uri** | **str** |  | [optional] 
**provenance_uri** | **str** |  | [optional] 
**object_uri** | **str** |  | [optional] 
**variable_uri** | **str** |  | [optional] 
**_date** | **datetime** |  | [optional] 
**value** | **object** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


