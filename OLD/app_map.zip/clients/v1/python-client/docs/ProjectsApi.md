# WeisWSClient.ProjectsApi

All URIs are relative to *http://www.opensilex.org:8080/weisAPI/rest*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_by_id**](ProjectsApi.md#get_by_id) | **GET** /projects/{uri} | Get a project by its URI.
[**get_by_search**](ProjectsApi.md#get_by_search) | **GET** /projects | Get all projects corresponding to the searched params given
[**post3**](ProjectsApi.md#post3) | **POST** /projects | Post a project
[**put2**](ProjectsApi.md#put2) | **PUT** /projects | Put project(s)


# **get_by_id**
> list[ProjectDetailDTO] get_by_id(uri, authorization, page_size=page_size, page=page)

Get a project by its URI.

Retrieve the project authorized for the user corresponding to theU RI given

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.ProjectsApi(pythonClient)
uri = '\"http://www.opensilex.org/demo/projectTest\"' # str | A project URI (Unique Resource Identifier)
page_size = 20 # int | Number of elements per page (limited to 150000) (optional) (default to 20)
page = 0 # int | Current page number (optional) (default to 0)


try:
    # Get a project by its URI.
    api_response = api_instance.get_by_id(uri, page_size=page_size, page=page)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ProjectsApi->get_by_id: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **uri** | **str**| A project URI (Unique Resource Identifier) | 
 **page_size** | **int**| Number of elements per page (limited to 150000) | [optional] [default to 20]
 **page** | **int**| Current page number | [optional] [default to 0]


### Return type

[**list[ProjectDetailDTO]**](ProjectDetailDTO.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_by_search**
> list[ProjectDTO] get_by_search(authorization, page_size=page_size, page=page, uri=uri, name=name, shortname=shortname, financial_funding=financial_funding, financial_funding_lang=financial_funding_lang, financial_reference=financial_reference, description=description, start_date=start_date, end_date=end_date, home_page=home_page, objective=objective)

Get all projects corresponding to the searched params given

Retrieve all projects authorized for the user corresponding to the searched params given

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.ProjectsApi(pythonClient)
page_size = 20 # int | Number of elements per page (limited to 150000) (optional) (default to 20)
page = 0 # int | Current page number (optional) (default to 0)
uri = '\"http://www.opensilex.org/demo/projectTest\"' # str | Search by URI (optional)
name = '\"projectTest\"' # str | Search by project name (optional)
shortname = '\"P T\"' # str | Search by shortname (optional)
financial_funding = '\"financial name\"' # str | Search by financial funding (optional)
financial_funding_lang = '\"fr\"' # str | Search by financial funding lang (optional)
financial_reference = '\"financial reference\"' # str | Search by financial reference (optional)
description = '\"This project is about maize.\"' # str | Search by description (optional)
start_date = '\"2015-07-07\"' # str | Search by start date (optional)
end_date = '\"2016-07-07\"' # str | Search by end date (optional)
home_page = '\"http://example.com\"' # str | Search by home page (optional)
objective = '\"This is the objective of the project.\"' # str | Search by objective (optional)


try:
    # Get all projects corresponding to the searched params given
    api_response = api_instance.get_by_search(page_size=page_size, page=page, uri=uri, name=name, shortname=shortname, financial_funding=financial_funding, financial_funding_lang=financial_funding_lang, financial_reference=financial_reference, description=description, start_date=start_date, end_date=end_date, home_page=home_page, objective=objective)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ProjectsApi->get_by_search: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page_size** | **int**| Number of elements per page (limited to 150000) | [optional] [default to 20]
 **page** | **int**| Current page number | [optional] [default to 0]
 **uri** | **str**| Search by URI | [optional] 
 **name** | **str**| Search by project name | [optional] 
 **shortname** | **str**| Search by shortname | [optional] 
 **financial_funding** | **str**| Search by financial funding | [optional] 
 **financial_funding_lang** | **str**| Search by financial funding lang | [optional] 
 **financial_reference** | **str**| Search by financial reference | [optional] 
 **description** | **str**| Search by description | [optional] 
 **start_date** | **str**| Search by start date | [optional] 
 **end_date** | **str**| Search by end date | [optional] 
 **home_page** | **str**| Search by home page | [optional] 
 **objective** | **str**| Search by objective | [optional] 


### Return type

[**list[ProjectDTO]**](ProjectDTO.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post3**
> ResponseFormPOST post3(authorization, body=body)

Post a project

Register a new project in the database

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.ProjectsApi(pythonClient)
body = [WeisWSClient.ProjectPostDTO()] # list[ProjectPostDTO] | JSON format of project data (optional)


try:
    # Post a project
    api_response = api_instance.post3(body=body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ProjectsApi->post3: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**list[ProjectPostDTO]**](ProjectPostDTO.md)| JSON format of project data | [optional] 


### Return type

[**ResponseFormPOST**](ResponseFormPOST.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **put2**
> ResponseFormPOST put2(authorization, body=body)

Put project(s)

Update project(s) in the database

### Example
```python
from __future__ import print_function
import time
import WeisWSClient
from WeisWSClient.rest import ApiException
from pprint import pprint

# create an instance of the API class
pythonClient = WeisWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="user_email",password="password")
api_instance = WeisWSClient.ProjectsApi(pythonClient)
body = [WeisWSClient.ProjectPutDTO()] # list[ProjectPutDTO] | JSON format of project data (optional)


try:
    # Put project(s)
    api_response = api_instance.put2(body=body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ProjectsApi->put2: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**list[ProjectPutDTO]**](ProjectPutDTO.md)| JSON format of project data | [optional] 


### Return type

[**ResponseFormPOST**](ResponseFormPOST.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

