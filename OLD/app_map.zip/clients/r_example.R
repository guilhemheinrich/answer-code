library(opensilexWSClient)
# Le chargement a nécessité le package : opensilexWSClientR
opensilexWSClient::connectToPHISWS(apiID="ws_private",username="admin@opensilex.org",password="admin", url = "http://localhost:8080/opensilex/rest/")
# 2019-10-04 10:05:40 INFO::Query executed and data recovered - WS2
annoService <- AnnotationsApi$new()


newAnnotation <- AnnotationDTO$new()
newAnnotation$motivatedBy <- "http://www.w3.org/ns/oa#assessing"
newAnnotation$creator <- "http://www.sunagri.fr/sunagri/id/agent/admin_sunagri"
newAnnotation$targets <- list("http://www.opensilex.org/sunagri/SUA2016-2")
newAnnotation$bodyValues <- list("testAnnot")
annoService$post1(body = newAnnotation)


annot <- annoService$get_annotations_by_search(target = "http://www.opensilex.org/sunagri/SUA2016-2")
annot
# <Response>
#   Public:
#     clone: function (deep = FALSE) 
#     content: AnnotationDTO, R6
#     initialize: function (content, response) 
#     response: response
#     wsResponse: list, WSResponse

