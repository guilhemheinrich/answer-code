
### V3.4

# from __future__ import print_function
# import time
# import opensilexWSClient
# from opensilexWSClient.rest import ApiException
# from pprint import pprint

# # usage of a created instance of the API class
# pythonClient = opensilexWSClient.ApiClient()
# pythonClient.connect_to_opensilex_ws(username="admin@opensilex.org",password="admin",host="http://localhost:8666/rest")

# api_instance = opensilexWSClient.SecurityApi(pythonClient)
# try:
#     # Get all users corresponding to the searched params given
#     api_response = api_instance.search_users()
#     pprint(api_response)
# except ApiException as e:
#     print("Exception when calling UserApi->get_user_by_search: %s\n" % e)

# factor_api = opensilexWSClient.FactorsApi(pythonClient)
# body = opensilexWSClient.FactorCreationDTO(names={'en':'testGenerate'},comment='testGenerate') # FactorCreationDTO | Factor description (optional)


# try:
#     # Create an factor
#     api_response =factor_api.create_factor_with_http_info(body=body,)
#     pprint(api_response)
# except ApiException as e:
#     print("Exception when calling FactorsApi->create_factor: %s\n" % e)

# try:
#     # Create an factor
#     body = opensilexWSClient.FactorSearchDTO() # FactorCreationDTO | Factor description (optional)

#     api_response =factor_api.search_factors(body=body)
#     pprint(api_response)
# except ApiException as e:
#     print("Exception when calling FactorsApi->create_factor: %s\n" % e)
 
# api_instance = opensilexWSClient.ProjectsApi(pythonClient)
# try:
#     api_response =api_instance.get_by_id(uri="dev-prj:sasa")
#     pprint(api_response)
# except ApiException as e:
#     print("Exception when calling FactorsApi->create_factor: %s\n" % e)
 
# api_instance = opensilexWSClient.ProjectsApi(pythonClient)
# try:
#     newProject = opensilexWSClient.ProjectCreationDTO(shortname="test_shot",label="test",start_date="2017-06-15",end_date="2017-06-16",)
   
#     api_response = api_instance.create_project(body=newProject)
#     pprint(api_response)
# except ApiException as e:
#      print("Exception when calling ProjectsApi->post3: %s\n" % e)
 
# ### V3.3

from __future__ import print_function
import time
import opensilexWSClient
from opensilexWSClient.rest import ApiException
from pprint import pprint
pythonClient = opensilexWSClient.ApiClient()
pythonClient.connect_to_opensilex_ws(username="admin@opensilex.org",password="admin")
print(pythonClient.default_headers)

# # create an instance of the API class
# targets = ["http://www.opensilex.org/sunagri/id/event/922073aa-82b6-498f-97a4-39ee1062257f"]
# annot = opensilexWSClient.AnnotationPostDTO(
# creator="http://www.sunagri.fr/sunagri/id/agent/admin_sunagri",
# motivated_by="http://www.w3.org/ns/oa#commenting",
# targets=targets,
# body_values=["testclient4"]
# )
# body = [annot]

# annotation_api_instance = opensilexWSClient.AnnotationsApi(pythonClient)
# try:
#     api_response = annotation_api_instance.post1(body = body)
#     print(" \nresult : \n")
#     pprint(api_response)
# except ApiException as e:
#     print("Exception : %s\n" % e)

# # get an instance of the API class
# annotation_api_instance = opensilexWSClient.AnnotationsApi(pythonClient)
# page_size = 20 # int | Number of elements per page (limited to 150000) (optional) (default to 20)
# try:
#     api_response = annotation_api_instance.get_annotations_by_search(page_size=page_size)
#     pprint(api_response)
# except ApiException as e:
#     print("Exception : %s\n" % e)

