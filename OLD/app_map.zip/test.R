library(phisWSClientRTools)
connectToPHISWS(apiID="ws_private",
                #url = "http://138.102.159.37:8080/openSilexTestAPI/rest/",
                url = "http://www.opensilex.org/openSilexSandBoxAPI/rest/",
                username="admin@opensilex.org",
                password="admin")
setLogLevel(level = "DEBUG")
getUserInformations()

# Pour 1 Obj Scient - version R6
rawSO = read.table(file = "/home/charlero/Téléchargements/ao_mau17.csv", sep = ";", dec = ".", header = TRUE, stringsAsFactors = FALSE)
rawSO$Experiment = "http://www.opensilex.org/demo/DMO2000-1"
sub_SO = rawSO[1:3,]
nSO = ScientificObjectPostDTO$new()
#properties
nPo = PropertyPostDTO$new(
  rdfType = "http://www.opensilex.org/vocabulary/oeso#Species",
  relation = "http://www.opensilex.org/vocabulary/oeso#hasSpecies",
  value = "http://www.opensilex.org/vocabulary/oeso#zea_mays"
)
nPo2 = PropertyPostDTO$new(
  rdfType =  "http://www.opensilex.org/vocabulary/oeso#Variety",
  relation = "http://www.opensilex.org/vocabulary/oeso#hasVariety",
  value = sub_SO$Variety[1]
)
nPo3 = PropertyPostDTO$new()
nPo3$rdfType =   NA
nPo3$relation = "http://www.w3.org/2000/01/rdf-schema#label"
nPo3$value = sub_SO$Alias[1]

nSO$rdfType = paste("http://www.opensilex.org/vocabulary/oeso#",sub_SO$Type[1], sep = "")
nSO$geometry = sub_SO$Geometry[1]
nSO$experiment = sub_SO$Experiment[1]
# nSO$isPartOf = sub_SO$Experiment[1]
#nSO$year = "2020"
nSO$properties = list( nPo2, nPo3)
#nSO$properties = list(nPo3)
nSO$toJSON()
nSO$toJSONString()
nSO

post_so = ScientificObjectsApi$new()
soso = post_so$post_scientific_object(list(nSO))
soso$data
soso$metadata

so_api = ScientificObjectsApi$new()

get_so = so_api$get_scientific_objects_by_search(experiment = "http://www.opensilex.org/demo/DMO2000-1")
get_so$data
SO = getScientificObjects(experiment = "http://www.opensilex.org/demo/DMO2000-1")
SO$data
