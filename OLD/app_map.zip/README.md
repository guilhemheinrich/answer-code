# opensilex-ws-clients
<!-- TOC -->

- [opensilex-ws-clients](#opensilex-ws-clients)
  - [Clients generation](#clients-generation)
    - [Configuration file](#configuration-file)
    - [R](#r)
    - [phisWSClientRTools](#phiswsclientrtools)
    - [Python](#python)
    - [Typescript](#typescript)
    - [Minimalist usage examples](#minimalist-usage-examples)
  - [More information](#more-information)
    - [Supported languages description](#supported-languages-description)
    - [Understand swagger mustache templating](#understand-swagger-mustache-templating)
    - [Documentation](#documentation)
    - [OpenAPI Spec 2.X](#openapi-spec-2x)
    - [WS maven library description for OpenAPI Spec 2.X](#ws-maven-library-description-for-openapi-spec-2x)
    - [OpenAPI Spec 3.X](#openapi-spec-3x)
    - [WS maven library description for OpenAPI Spec 3.X](#ws-maven-library-description-for-openapi-spec-3x)
    - [Closed migration issue](#closed-migration-issue)
    - [How to debug swagger model](#how-to-debug-swagger-model)

<!-- /TOC -->

Here are defined some templates to generated client for OpenSILEX Webservice (3.X.X version)).

- Steps :
  - Clone this repository
    - ```git clone git@forgemia.inra.fr:OpenSILEX/opensilex-ws-clients.git```
  - Download swagger-codegen-cli.jar inside the repo directory
    - ```cd opensilex-ws-clients```
    - ```wget https://repo1.maven.org/maven2/io/swagger/swagger-codegen-cli/2.4.8/swagger-codegen-cli-2.4.8.jar -O swagger-codegen-cli.jar```
  - Generate clients :
    - [R](#R)
    - [Python](#Python)

## Clients generation

### Configuration file

Can add any variable use in the mustache template which is used by swagger generator.

```json
{
  "packageName" : "opensilexWSClient",
  "packageVersion" : "3.4.0",
}
```

### R
**For OpenSILEX ( 3.3 <=) local installation**

These following lines will create, document, install new generated the client.

Required packages in R environment:

- roxygen2
- usethis

On ubuntu, these packages required the following system libraries : ```bash -y libcurl4-openssl-dev libssh2-1-dev libssl-dev libgit2-dev libxml2-dev```

In a R console, run the following command line :  ```r install.packages(c('roxygen2','usethis')) ```

```bash
# create client directory and go in to this directory
# generate client using
# - swagger json url
# - language
# - generated directory
# - set variable in config.js
# generate documentation
# create a Rstudio project
# install package in this R environment
rm -Rf clients/v1/r-client && mkdir -p clients/v1/r-client \
&& \
java -jar swagger-codegen-cli.jar generate \
  -i http://138.102.159.36:8080/rest/swagger.json \
  -l r \
  -o clients/r-client \
  -t templates/v1/r \
  -c templates/v1/r/config.json \
&& \
rm  clients/r-client/NAMESPACE \
&& \
R -e 'setwd(paste0(getwd(),"/clients/r-client"));roxygen2::roxygenise();' \
&& \
R -e 'setwd(paste0(getwd(),"/clients/r-client"));usethis::use_rstudio();' \
&& \
R CMD INSTALL --no-multiarch --with-keep.source  clients/r-client
```

### phisWSClientRTools

```bash
# create client directory and go in to this directory
# generate client using
# - swagger json url
# - language
# - generated directory
# - set variable in config.js
# generate documentation
# create a Rstudio project
# install package in this R environment
rm -Rf clients/v1/r-client && mkdir -p clients/v1/r-client \
&& \
java -jar swagger-codegen-cli.jar generate \
  -i http://www.opensilex.org/openSilexSandBoxAPI/rest/swagger.json \
  -l r \
  -o clients/r-client \
  -t templates/v1/r \
  -c templates/v1/r/config.json \
&& \
rm  clients/r-client/NAMESPACE \
&& \
find clients/r-client -type f -exec sed -i 's/TODO_OBJECT_MAPPING/ObjectDTO/g' {} + \
&& \
R -e 'setwd(paste0(getwd(),"/clients/r-client"));roxygen2::roxygenise();' \
&& \
R -e 'setwd(paste0(getwd(),"/clients/r-client"));usethis::use_rstudio();' \
&& \
R CMD INSTALL --no-multiarch --with-keep.source  clients/r-client
```

```json
{
  "packageName" : "phisWSClientRTools",
  "packageVersion" : "3.3.0"
}
```

### Python

These following lines will create, document, install new generated the client.
**For OpenSILEX ( 3.3 <=) local installation**

```bash
# create client directory and go in to this directory
# generate client using 
# - swagger json url
# - language
# - generated directory
# - set variable in config.js
# install client in to this python environment
rm -Rf clients/v1/python-client && mkdir -p clients/v1/python-client \
&& \
java -jar swagger-codegen-cli.jar generate \
  -i http://localhost:8080/opensilex/rest/swagger.json \
  -l python \
  -o clients/v1/python-client \
  -t templates/v1/python \
  -c templates/v1/python/config.json 

cd clients/v1/python-client && python setup.py install --user
```

**For OpenSILEX (> 3.3) local installation**
```bash
# create client directory and go in to this directory
# generate client using 
# - swagger json url
# - language
# - generated directory
# - set variable in config.js
# install client in to this python environment
rm -Rf clients/v2/python-client && mkdir -p clients/v2/python-client \
&& \
java -jar swagger-codegen-cli.jar generate \
  -i http://localhost:8666/rest/swagger.json \
  -l python \
  -o clients/v2/python-client \
  -t templates/v2/python \
  -c templates/v2/python/config.json
 
cd clients/v2/python-client && python setup.py install --user
```

### Typescript


These following lines will create, document, install new generated the client.

```bash
# create client directory and go in to this directory
# generate client using 
# - swagger json url
# - language
# - generated directory
# - set variable in config.js
rm -Rf clients/typescript-client && mkdir -p clients/typescript-client \
&& \
java -jar swagger-codegen-cli.jar generate \
  -i http://138.102.159.37:8080/openSilexTestAPI/rest/swagger.json \
  -l typescript-fetch \
  -o clients/typescript-client \
  -t templates/typescript-fetch \
  -c templates/typescript-fetch/config.json 
```

### Minimalist usage examples

- clients/r_example.py
- clients/python_example.py

For more information see the auto-generated documentation

## More information

### Supported languages description

<https://github.com/swagger-api/swagger-codegen/tree/master/modules/swagger-codegen/src/main/resources>

### Understand swagger mustache templating

<https://github.com/swagger-api/swagger-codegen/wiki/Mustache-Template-Variables>

### Documentation

<https://github.com/swagger-api/swagger-codegen>

### OpenAPI Spec 2.X

```bash
wget http://central.maven.org/maven2/io/swagger/swagger-codegen-cli/2.4.8/swagger-codegen-cli-2.4.8.jar -O swagger-codegen-cli.jar

```

### WS maven library description for OpenAPI Spec 2.X

<https://github.com/swagger-api/swagger-core/wiki/Annotations-1.5.X>

### OpenAPI Spec 3.X

```bash
<!-- wget http://central.maven.org/maven2/org/openapitools/openapi-generator-cli/3.3.4/openapi-generator-cli-3.3.4.jar -O openapi-generator-cli.jar -->

```

### WS maven library description for OpenAPI Spec 3.X

<https://github.com/swagger-api/swagger-core/wiki/Swagger-2.X---Getting-started>

### Closed migration issue

<https://github.com/OpenSILEX/phis-ws/issues/32>

### How to debug swagger model

```bash
java -jar swagger-codegen-cli.jar generate \
  -i http://localhost:8080/opensilex/rest/swagger.json \
  -l r \
  -o clients/r-client \
  -t templates/v1/r \
  -c templates/v1/r/config.json \
    -DdebugModels \
    -DdebugOperations >> debug.json
```
